// Products the user can pick in the "product" popup.
// `category` must match the Category column of the catalog CSV: the board shows
// the references of the selected product's category (shoes, bags, jackets, boots).
// Names, list prices, photos and tags come from the approved popup mockups.

export type ProductCategory = "Shoe" | "Bag" | "Jacket" | "Boots"

export type Product = {
  id: string
  category: ProductCategory
  name: string
  /** List price in USD. */
  price: number
  image: string
  /** "NEW IN" badge. */
  isNew?: boolean
  /** Co-Creation sparkle icon on the photo. */
  sparkle?: boolean
  /** Shows "Personalizzabile solo in-store" on the photo. */
  inStoreOnly?: boolean
}

export const products: Product[] = [
  // Sneakers
  { id: "sneaker-gold-glitter-ice", category: "Shoe", name: "Women's Super-Star with gold glitter star and ice gray suede inserts", price: 595, image: "/assets/products/sneaker-gold-glitter-ice.jpg" },
  { id: "sneaker-men-grey-suede", category: "Shoe", name: "Men's Super-Star in light grey suede with white leather star", price: 640, image: "/assets/products/sneaker-men-grey-suede.jpg", isNew: true, sparkle: true },
  { id: "super-star", category: "Shoe", name: "Women's Super-Star with gold star and black glitter heel tab", price: 595, image: "/assets/products/super-star.jpg" },
  { id: "sneaker-white-glitter-heel", category: "Shoe", name: "Women's white leather Super-Star with glittery heel tab", price: 595, image: "/assets/products/sneaker-white-glitter-heel.jpg" },
  // Bags
  { id: "bag-brown-scarf", category: "Bag", name: "Brown leather bag with scarf detail", price: 595, image: "/assets/products/bag-brown-scarf.jpg" },
  { id: "bag-tan-tote-tassel", category: "Bag", name: "Tan suede tote with tassel", price: 640, image: "/assets/products/bag-tan-tote-tassel.jpg" },
  { id: "bag-dark-tote", category: "Bag", name: "Dark leather tote", price: 595, image: "/assets/products/bag-dark-tote.jpg" },
  { id: "bag-tan-handbag", category: "Bag", name: "Tan suede handbag", price: 595, image: "/assets/products/bag-tan-handbag.jpg" },
  // Boots
  { id: "boots-green-embroidered", category: "Boots", name: "Green embroidered tall boots", price: 595, image: "/assets/products/boots-green-embroidered.jpg", inStoreOnly: true },
  { id: "boots-black-harness", category: "Boots", name: "Black leather harness boots", price: 640, image: "/assets/products/boots-black-harness.jpg", inStoreOnly: true },
  { id: "boots-brown-harness", category: "Boots", name: "Brown suede harness boots", price: 595, image: "/assets/products/boots-brown-harness.jpg", inStoreOnly: true },
  { id: "boots-black-western", category: "Boots", name: "Black embroidered western boots", price: 595, image: "/assets/products/boots-black-western.jpg", inStoreOnly: true },
  // Jackets
  { id: "jacket-distressed-biker", category: "Jacket", name: "Distressed leather biker jacket", price: 595, image: "/assets/products/jacket-distressed-biker.jpg", inStoreOnly: true },
  { id: "jacket-suede-fringe", category: "Jacket", name: "Brown suede fringe jacket", price: 640, image: "/assets/products/jacket-suede-fringe.jpg", inStoreOnly: true },
  { id: "jacket-black-varsity", category: "Jacket", name: "Black varsity jacket", price: 595, image: "/assets/products/jacket-black-varsity.jpg", inStoreOnly: true },
  { id: "jacket-leopard-biker", category: "Jacket", name: "Distressed biker jacket with leopard-print lining", price: 595, image: "/assets/products/jacket-leopard-biker.jpg", inStoreOnly: true },
]

export const defaultProductId = "super-star"

/** Order of the category row in the popup. */
export const categoryOrder: ProductCategory[] = ["Shoe", "Bag", "Boots", "Jacket"]

export const categoryLabels: Record<ProductCategory, string> = {
  Shoe: "Sneakers",
  Bag: "Bags",
  Boots: "Boots",
  Jacket: "Jackets",
}

export const categoryThumbs: Record<ProductCategory, string> = {
  Shoe: "/assets/categories/sneakers.jpg",
  Bag: "/assets/categories/bags.jpg",
  Boots: "/assets/categories/boots.jpg",
  Jacket: "/assets/categories/jackets.jpg",
}

export const coCreationLabel = "with Co-Creation"

// The approved drawer mockup shows $720 for the $595 Super-Star, so Co-Creation
// adds $125. ASSUMPTION: the same fee is applied to every product. Change it
// here, or give a product its own price, if that is not right.
export const coCreationFee = 125
export const coCreationPrice = (product: Product) => product.price + coCreationFee

export const formatPrice = (price: number) => `$ ${price.toLocaleString("en-US")}`
