import { useEffect, useId, useRef, useState } from "react"
import { ProductPopup } from "./ProductPopup"
import {
  coCreationLabel,
  coCreationPrice,
  formatPrice,
  type Product,
} from "./products"

export function ProductDrawer({
  products,
  selectedId,
  onSelect,
}: {
  products: Product[]
  selectedId: string
  onSelect: (id: string) => void
}) {
  const [open, setOpen] = useState(false)
  const [popupOpen, setPopupOpen] = useState(false)
  const rootRef = useRef<HTMLElement>(null)
  const bodyId = useId()
  const selected = products.find((p) => p.id === selectedId) ?? products[0]

  useEffect(() => {
    if (!open) return
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return
      if (!rootRef.current?.contains(document.activeElement)) return
      setOpen(false)
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [open])

  return (
    <>
    <aside
      ref={rootRef}
      className={`product-drawer${open ? " product-drawer-open" : ""}`}
      aria-label="Selected product"
      onPointerDown={(event) => event.stopPropagation()}
    >
      <button
        className="product-tab"
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-expanded={open}
        aria-controls={bodyId}
      >
        <span>product</span>
      </button>

      <div className="product-body" id={bodyId} inert={!open}>
        <button
          className="product-image"
          type="button"
          onClick={() => setPopupOpen(true)}
          aria-haspopup="dialog"
          aria-label={`Change product. Current: ${selected.name}`}
        >
          <img src={selected.image} alt="" draggable={false} />
          <span className="product-change">
            Cambia
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M4 20h4L19 9l-4-4L4 16v4zM13.5 6.5l4 4" />
            </svg>
          </span>
        </button>
        <div className="product-info" aria-live="polite">
          <p className="product-name">{selected.name}</p>
          <p className="product-price">
            <strong>{formatPrice(coCreationPrice(selected))}</strong>
            <span>{coCreationLabel}</span>
          </p>
        </div>
      </div>
    </aside>

      {/* On small screens the drawer is replaced by this button, which opens the popup directly. */}
      <button
        className="product-chip"
        type="button"
        onClick={() => setPopupOpen(true)}
        aria-haspopup="dialog"
        aria-label={`Product: ${selected.name}, ${formatPrice(coCreationPrice(selected))} ${coCreationLabel}. Change product`}
      >
        <img src={selected.image} alt="" draggable={false} />
        <span className="product-chip-text">
          <span className="product-chip-price">
            {coCreationPrice(selected).toLocaleString("en-US")}$
          </span>
          <span className="product-chip-note">{coCreationLabel}</span>
        </span>
        <svg
          className="product-chip-caret"
          viewBox="0 0 12 12"
          aria-hidden="true"
        >
          <path d="M2.5 4.5 6 8l3.5-3.5" />
        </svg>
      </button>

      {popupOpen && (
        <ProductPopup
          products={products}
          selectedId={selectedId}
          onSelect={onSelect}
          onClose={() => setPopupOpen(false)}
        />
      )}
    </>
  )
}
