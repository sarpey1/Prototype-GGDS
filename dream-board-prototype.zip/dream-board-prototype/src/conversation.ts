// Scripted "emotional AI" for the Co-Creation concept showcase.
// It listens to the story (people, places, moments, feelings, in Italian or
// English), answers in the user's language, asks three targeted questions about
// the visual mark, and ends with a concrete design brief for the chosen product.
// No network calls, so it is predictable on stage. To plug in a live model,
// replace `getQuestion`, `reflectionLines` and `buildBrief`.

export type Lang = "en" | "it"
export type Axis = "intimate" | "road" | "artistic"
export type AxisScores = Record<Axis, number>
export type MotifKey = "name" | "place" | "date" | "feeling"
export type ToneKey = "warm" | "free" | "energy"
export type Visibility = "hidden" | "small" | "bold"
// Personalizations the Dream Makers actually offer (hand lettering and embroidery,
// drawings, crystals and studs, charms and patches).
export type TouchKey = "words" | "drawing" | "sparkle" | "accessory"
export type CraftKey =
  | "ink" | "marker" | "thread" | "paint" | "spray" | "stamp" | "brush" | "crystal" | "foil" | "charm"
  | "neon" | "graffiti" | "ticket" | "patch"
export type ConceptKey = "neon" | "street" | "keepsake"
export type FinishKey = "clean" | "lived" | "worn"
export type Tag = {
  motif?: MotifKey
  tone?: ToneKey
  visibility?: Visibility
  touches?: TouchKey[]
  craft?: CraftKey
  concept?: ConceptKey
  finish?: FinishKey
  ai?: string[]
}
export type Category = "Shoe" | "Bag" | "Jacket" | "Boots"
export type Entities = {
  person?: string
  place?: string
  time?: string
  feeling?: string
}
export type Option = { label: string; weights: Partial<AxisScores>; tag?: Tag }
export type Question = { prompt: string; options: Option[]; lead?: string }
export type Brief = {
  motif: string
  palette: string
  technique: string
  finish: string
  placement: string
  touches?: string
}

export const totalQuestions = 5
export const emptyScores: AxisScores = { intimate: 0, road: 0, artistic: 0 }

// ---------------------------------------------------------------- language

const itWords = new Set(
  "il lo la le gli un una di che è non per con mi ho ero era sono del della nel nella mia mio miei dove quando ricordo anni tutto ma poi come più c'era sempre quella quello questo ci si ti ne al alla dei delle".split(
    " ",
  ),
)
const enWords = new Set(
  "the an and of to was were my with when it that for on we she he is at this there had have our me you your what where".split(
    " ",
  ),
)

export const detectLang = (text: string, fallback: Lang = "en"): Lang => {
  const tokens = text.toLowerCase().match(/[\p{L}']+/gu) ?? []
  const it = tokens.filter((word) => itWords.has(word)).length
  const en = tokens.filter((word) => enWords.has(word)).length
  if (it > en) return "it"
  if (en > it) return "en"
  return fallback
}

// ---------------------------------------------------------------- listening

const word = (alternatives: string) =>
  new RegExp(`(?<![\\p{L}])(${alternatives})(?![\\p{L}])`, "iu")

const lexicon: Record<keyof Entities, RegExp> = {
  person: word(
    "nonn[aoie]|grand(?:mother|father|ma|pa|parents?)|mamm[ae]|madre|mother|mom|mum|pap[àa]|padre|father|dad|fratell[oi]|sorell[ae]|brother|sister|amic[oahie]|friends?|figli[oae]|son|daughter|bambin[oaie]|child|children|marit[oi]|mogli[ei]|husband|wife|fidanzat[oae]|girlfriend|boyfriend|partner|zi[oa]|uncle|aunt|cugin[oae]|cousin",
  ),
  place: word(
    "cucina|kitchen|mare|sea|beach|spiaggia|montagn[ae]|mountains?|deserto|desert|venezia|venice|milano|milan|parigi|paris|roma|rome|napoli|naples|new york|giardino|garden|scuola|school|stazione|station|aeroporto|airport|lago|lake|campagna|countryside|isola|island|bosco|forest|piazza|negozio|shop|palco|stage",
  ),
  time: word(
    "estate|summer|inverno|winter|autunno|autumn|primavera|spring|notte|night|alba|sunrise|tramonto|sunset|mattina|morning|natale|christmas|matrimonio|wedding|compleanno|birthday|laurea|graduation|capodanno|\\d{4}",
  ),
  feeling: word(
    "libert[àa]|freedom|nostalgia|felicit[àa]|happiness|gioia|joy|amore|love|mancanza|orgoglio|pride|proud|paura|fear|coraggio|courage|pace|peace|silenzio|silence|risate|laughter",
  ),
}

// Too generic to be the heart of a story, used only when nothing more specific appears.
const genericPlace = word("citt[àa]|city|strad[ae]|road|highway|casa|home|house")

export const extractEntities = (text: string): Entities => {
  const found: Entities = {}
  ;(Object.keys(lexicon) as (keyof Entities)[]).forEach((key) => {
    const match = text.match(lexicon[key]) ?? (key === "place" ? text.match(genericPlace) : null)
    if (match) found[key] = match[1]
  })
  return found
}

const stems: Record<Axis, string[]> = {
  intimate: [
    "segret", "sussurr", "nome", "nomi", "data", "lettera", "lettere", "nonn",
    "mamm", "madre", "pap", "padre", "amore", "casa", "cucina", "silenzio",
    "privat", "inizial", "famigli", "bambin", "matrimonio", "manc", "secret",
    "whisper", "name", "date", "letter", "grand", "mother", "mom", "father",
    "dad", "love", "home", "kitchen", "quiet", "private", "initial", "family",
    "child", "wedding", "miss", "birthday",
  ],
  road: [
    "strad", "guid", "viagg", "asfalto", "chilometr", "cammin", "vagabond",
    "consum", "polvere", "citt", "estate", "avventur", "corr", "passegg",
    "venezia", "autostrada", "volo", "partenz", "desert", "road", "drive",
    "travel", "trip", "asphalt", "mile", "journey", "wander", "worn", "dust",
    "city", "summer", "adventure", "run", "walk", "venice", "street", "highway",
    "flight", "paris", "milan",
  ],
  artistic: [
    "color", "colour", "dipin", "disegn", "music", "ball", "libert", "selvagg",
    "arte", "audace", "rider", "risat", "fest", "celebr", "giocar", "schizz",
    "concert", "sogn", "luminos", "paint", "draw", "danc", "free", "wild",
    "art", "bold", "laugh", "party", "play", "sketch", "dream", "bright",
    "loud", "joy", "gioia",
  ],
}
const stemRegex = (stem: string) => new RegExp(`(?<![\\p{L}])${stem}`, "iu")
const stemMatchers = Object.fromEntries(
  (Object.keys(stems) as Axis[]).map((axis) => [axis, stems[axis].map(stemRegex)]),
) as Record<Axis, RegExp[]>

export const scoreText = (text: string): AxisScores => {
  const scores = { ...emptyScores }
  ;(Object.keys(stemMatchers) as Axis[]).forEach((axis) => {
    scores[axis] = Math.min(
      3,
      stemMatchers[axis].filter((matcher) => matcher.test(text)).length,
    )
  })
  return scores
}

export const addScores = (a: AxisScores, b: Partial<AxisScores>): AxisScores => ({
  intimate: a.intimate + (b.intimate ?? 0),
  road: a.road + (b.road ?? 0),
  artistic: a.artistic + (b.artistic ?? 0),
})

export const hasSignal = (s: AxisScores) => s.intimate + s.road + s.artistic > 0

// Highest score first; ties keep this fixed order.
export const rankAxes = (s: AxisScores): Axis[] =>
  (["intimate", "road", "artistic"] as Axis[]).sort((a, b) => s[b] - s[a])

// The pre-written Tokyo story has its own hand-written path (see tokyoQuestion).
export const isTokyoStory = (memory: string) => /tokyo|shinjuku|giappone|japan/i.test(memory)
const isItalianText = (text: string) => /\b(il|la|di|che|ero|giappone|mezzanotte)\b/i.test(text)

const snippet = (memory: string) => {
  if (isTokyoStory(memory))
    return isItalianText(memory) ? "persa a Shinjuku a mezzanotte" : "lost in Shinjuku at midnight"
  const trimmed = memory.trim().replace(/[.!?]+$/, "")
  const clause = trimmed.split(/[,;:.—–]/)[0].trim()
  const clean = clause.length >= 8 ? clause : trimmed
  if (clean.length <= 44) return clean
  const cut = clean.slice(0, 44)
  return `${cut.slice(0, cut.lastIndexOf(" ")).trimEnd() || cut}…`
}

// The detail the AI quotes back: it depends on what the story is about.
const anchorOf = (entities: Entities, lead: Axis) =>
  lead === "road"
    ? (entities.place ?? entities.person ?? entities.time ?? entities.feeling)
    : lead === "artistic"
      ? (entities.feeling ?? entities.place ?? entities.time ?? entities.person)
      : (entities.person ?? entities.place ?? entities.time ?? entities.feeling)

// ---------------------------------------------------------------- copy

const EN = {
  memoryTitle: "Unravel your Story",
  memoryHint: "A place, a person, a moment. A few lines are enough.",
  memoryPlaceholder: "It started when…",
  memorySubmit: "Next",
  sampleLabel: "Need a spark? Start from this",
  next: "Next",
  loadingTitle: "Setting the images from the Dream Maker archive that will fit your story...",
  back: "Back",
  startOver: "Start over",
  blank: "Write a few words to begin.",
  starters: [
    "I remember the day…",
    "There is someone who…",
    "The place where I feel at home is…",
  ],
  followupHint: "You can select more than 1 answer.",
  followupPlaceholder: "..or tell me with your own words",
  followupAria: "Answer in your own words",
  hear: (label: string) => `I hear “${label}”.`,
  confirm: "This is the visual of my story",
  another: "Show me another reading",
  briefLabels: {
    motif: "Mark",
    palette: "Colours",
    technique: "Technique",
    finish: "Finish",
    placement: "Placement",
    touches: "Touches",
  },
  pinTitle: ["Pin the Dream Maker works", "that inspire you the most."],
  done: "DONE",
  reset: "Reset",
  finalTitle: "This is only the beginning of your conversation with a Dream Maker.",
  book: "Book an appointment",
  save: "Save your card",
  finalReady: ["Your Concept Sheet is ready.", "A Dream Maker will handle", "the rest."],
  finalSub: "After purchasing, you can start pouring your vision to a Dream Maker. Use this as a reference.",
  finalBook: "Purchase product",
  finalSave: "View Card",
  sheetLabel: "YOUR CONCEPT SHEET",
  toastSaved: "Image saved",
  saved: "Card saved ✓",
  savedSr: "Your Story Card was saved as an image.",
  cardTitle: "Your Concept Sheet",
  sheetStyle: "Visual style",
  sheetDisclaimer: "This is only a concept. Talk to your Dream Maker to define the rest of the design.",
}

const IT: typeof EN = {
  memoryTitle: "Svela la tua storia",
  memoryHint: "Un luogo, una persona, un momento. Bastano poche righe.",
  memoryPlaceholder: "Tutto è iniziato quando…",
  memorySubmit: "Avanti",
  sampleLabel: "Serve una scintilla? Parti da qui",
  next: "Avanti",
  loadingTitle: "Sto scegliendo le immagini dall'archivio dei Dream Maker che si adattano alla tua storia...",
  back: "Indietro",
  startOver: "Ricomincia",
  blank: "Scrivi qualche parola per iniziare.",
  starters: [
    "Mi ricordo il giorno in cui…",
    "C'è una persona che…",
    "Il posto in cui mi sento a casa è…",
  ],
  followupHint: "Puoi selezionare più di una risposta.",
  followupPlaceholder: "..o raccontamelo con parole tue",
  followupAria: "Rispondi con parole tue",
  hear: (label: string) => `Sento “${label}”.`,
  confirm: "Questa è la visione della mia storia",
  another: "Mostrami un'altra lettura",
  briefLabels: {
    motif: "Segno",
    palette: "Colori",
    technique: "Tecnica",
    finish: "Finitura",
    placement: "Posizione",
    touches: "Tocchi",
  },
  pinTitle: ["Fissa le opere del Dream Maker", "che ti ispirano di più."],
  done: "FATTO",
  reset: "Da capo",
  finalTitle: "Questo è solo l'inizio della tua conversazione con un Dream Maker.",
  book: "Prenota un appuntamento",
  save: "Salva la scheda",
  finalReady: ["La tua Concept Sheet è pronta.", "Un Dream Maker si occuperà", "del resto."],
  finalSub: "Dopo l'acquisto, potrai iniziare a raccontare la tua visione a un Dream Maker. Usala come riferimento.",
  finalBook: "Acquista il prodotto",
  finalSave: "Vedi la scheda",
  sheetLabel: "LA TUA CONCEPT SHEET",
  toastSaved: "Immagine salvata",
  saved: "Scheda salvata ✓",
  savedSr: "La tua Story Card è stata salvata come immagine.",
  cardTitle: "Il tuo Concept Sheet",
  sheetStyle: "Stile visivo",
  sheetDisclaimer: "Questo è solo un concept. Parla con il tuo Dream Maker per definire il resto del design.",
}

// Ready-made stories so a tester can try the flow without typing. They land in
// the text box, where they can be edited before sharing.
export type SampleStory = { title: string; text: string }
export const sampleStories = (lang: Lang): SampleStory[] =>
  lang === "it"
    ? [
        {
          title: "Il mio primo viaggio a Tokyo",
          text: "La prima volta che sono stata in Giappone avevo ventotto anni e mi sono persa a Shinjuku a mezzanotte. Insegne al neon ovunque, distributori che brillavano sotto la pioggia e un minuscolo bancone di ramen dove nessuno parlava la mia lingua ma tutti mi hanno fatta sentire accolta. Mi sentivo di nuovo bambina, stupita da tutto. Voglio portare con me quello stupore.",
        },
      ]
    : [
        {
          title: "My first trip to Tokyo",
          text: "The first time I went to Japan I was twenty-eight, and I got lost in Shinjuku at midnight. Neon signs everywhere, vending machines glowing in the rain, and a tiny ramen counter where nobody spoke my language but everyone made me feel welcome. I felt like a child again, amazed by everything. I want to keep that wonder with me.",
        },
      ]

export const ui = (lang: Lang) => (lang === "it" ? IT : EN)

const directionLabels: Record<Lang, Record<Axis, string>> = {
  en: {
    intimate: "Quiet, whispered secret",
    road: "Marks of time and the road",
    artistic: "Free, expressive art",
  },
  it: {
    intimate: "Un segreto sussurrato",
    road: "I segni del tempo e della strada",
    artistic: "Arte libera ed espressiva",
  },
}
export const directionLabel = (lang: Lang, axis: Axis) => directionLabels[lang][axis]

// ---------------------------------------------------------------- the story

export const isThinStory = (text: string) =>
  (text.trim().match(/[\p{L}']+/gu) ?? []).length < 8

// A gentle reply to a story that is only the beginning of one.
export const nudgeLine = (lang: Lang, entities: Entities) => {
  const it = lang === "it"
  if (entities.place)
    return it
      ? `“${entities.place}” — ti ascolto. Chi c'era con te, e cosa hai sentito?`
      : `“${entities.place}” — I'm listening. Who was with you, and what did it feel like?`
  if (entities.person)
    return it
      ? `“${entities.person}” — dimmi di più. Dove eravate, e cosa vedevi intorno?`
      : `“${entities.person}” — tell me more. Where were you, and what did you see around you?`
  return it
    ? "Sento l'inizio di qualcosa. Dove eri, e chi c'era con te?"
    : "That is the beginning of something. Where were you, and who was there with you?"
}

// Three short lines, shown one after the other: what I heard, what I feel, what's next.
export const reflectionLines = (
  lang: Lang,
  memory: string,
  entities: Entities,
  scores: AxisScores,
): string[] => {
  const it = lang === "it"
  if (isTokyoStory(memory))
    return it
      ? [
          "Persa a Shinjuku a mezzanotte, e accolta lo stesso.",
          "Neon sotto la pioggia, e un minuscolo bancone in mezzo a una città gigante.",
          "Hai detto che vuoi tenere quello stupore. Ti faccio qualche domanda.",
        ]
      : [
          "Lost in Shinjuku at midnight, and somehow welcomed.",
          "Neon in the rain, and a tiny counter in the middle of a giant city.",
          "You said you want to keep that wonder. Let me ask you a few things.",
        ]
  const heard = [entities.person, entities.place, entities.time, entities.feeling]
    .filter((value): value is string => Boolean(value))
    .slice(0, 2)
    .map((value) => `“${value}”`)
  const first =
    heard.length === 2
      ? it
        ? `Sento ${heard[0]} e ${heard[1]} in quello che mi racconti.`
        : `I hear ${heard[0]} and ${heard[1]} in what you tell me.`
      : heard.length === 1
        ? it
          ? `Sento ${heard[0]} in quello che mi racconti.`
          : `I hear ${heard[0]} in what you tell me.`
        : it
          ? `“${snippet(memory)}” — sento che c'è di più dietro.`
          : `“${snippet(memory)}” — I can feel there is more behind it.`
  const lead = hasSignal(scores) ? rankAxes(scores)[0] : null
  const second =
    lead === "intimate"
      ? it
        ? "Sembra qualcosa di custodito con cura."
        : "It feels like something kept very close."
      : lead === "road"
        ? it
          ? "C'è movimento, e c'è usura."
          : "There is movement in it, and wear."
        : lead === "artistic"
          ? it
            ? "C'è colore. Quasi lo sento."
            : "There is colour in it. I can almost hear it."
          : it
            ? "I ricordi più veri nascono dai frammenti più piccoli."
            : "The truest memories bloom from the smallest fragments."
  const third = it
    ? "Ti faccio qualche domanda, così troviamo come dovrebbe apparire."
    : "Let me ask you a few things, so we can find how it should look."
  return [first, second, third]
}

// ---------------------------------------------------------------- the questions

const onProduct: Record<Lang, Record<Category, string>> = {
  en: { Shoe: "on the shoe", Bag: "on the bag", Jacket: "on the jacket", Boots: "on the boots" },
  it: { Shoe: "sulla scarpa", Bag: "sulla borsa", Jacket: "sulla giacca", Boots: "sugli stivali" },
}

type Context = {
  lang: Lang
  category: Category
  memory: string
  entities: Entities
  scores: AxisScores
  answers: Tag
}

const motifOption = (lang: Lang, key: MotifKey): Option => {
  const it = lang === "it"
  const table: Record<MotifKey, Option> = {
    name: {
      label: it ? "Parole scritte a mano" : "Hand-lettered words",
      weights: { intimate: 2 },
      tag: { motif: "name" },
    },
    place: {
      label: it ? "I colori di quel luogo" : "The colours of that place",
      weights: { road: 2 },
      tag: { motif: "place" },
    },
    date: {
      label: it ? "Un segno piccolo e discreto" : "A small, quiet mark",
      weights: { intimate: 1, road: 1 },
      tag: { motif: "date" },
    },
    feeling: {
      label: it ? "Un gesto di colore, libero" : "A free gesture of colour",
      weights: { artistic: 2 },
      tag: { motif: "feeling" },
    },
  }
  return table[key]
}

const toneOption = (lang: Lang, key: ToneKey): Option => {
  const it = lang === "it"
  const table: Record<ToneKey, Option> = {
    warm: {
      label: it ? "Calore, come tornare a casa" : "Warmth, like coming home",
      weights: { intimate: 2 },
      tag: { tone: "warm" },
    },
    free: {
      label: it ? "Libertà, aria aperta" : "Freedom, open air",
      weights: { road: 2 },
      tag: { tone: "free" },
    },
    energy: {
      label: it ? "Energia, voglia di esplodere" : "Energy, a need to burst out",
      weights: { artistic: 2 },
      tag: { tone: "energy" },
    },
  }
  return table[key]
}

const axisTone: Record<Axis, ToneKey> = { intimate: "warm", road: "free", artistic: "energy" }
const axisMotif: Record<Axis, MotifKey> = { intimate: "name", road: "place", artistic: "feeling" }
const axisVisibility: Record<Axis, Visibility> = { intimate: "hidden", road: "small", artistic: "bold" }

export const getQuestion = (step: number, ctx: Context): Question => {
  const { lang, category, memory, entities, scores, answers } = ctx
  const it = lang === "it"
  const lead: Axis = hasSignal(scores) ? rankAxes(scores)[0] : "intimate"
  const anchor = anchorOf(entities, lead)
  const on = onProduct[lang][category]
  if (isTokyoStory(memory)) return tokyoQuestion(step, lang, category, answers)

  if (step === 0) {
    const motifOrder: Record<Axis, MotifKey[]> = {
      intimate: ["name", "date", "feeling"],
      road: ["place", "date", "name"],
      artistic: ["feeling", "place", "name"],
    }
    const subject = anchor ? `“${anchor}”` : it ? "questo ricordo" : "this memory"
    return {
      prompt: it
        ? `Se ${subject} diventasse un segno ${on}, quale sarebbe?`
        : `If ${subject} became a mark ${on}, what would it be?`,
      options: motifOrder[lead].map((key) => motifOption(lang, key)),
    }
  }

  if (step === 1) {
    const toneOrder: ToneKey[] = [
      axisTone[lead],
      ...(["warm", "free", "energy"] as ToneKey[]).filter((k) => k !== axisTone[lead]),
    ]
    return {
      prompt: anchor
        ? it
          ? `E quando ripensi a “${anchor}”, cosa senti più forte?`
          : `And when you think of “${anchor}” now, what do you feel most?`
        : it
          ? "E quando ci ripensi, cosa senti più forte?"
          : "And when you think of it now, what do you feel most?",
      options: toneOrder.map((key) => toneOption(lang, key)),
    }
  }

  if (step === 2) return craftQuestion(lang, category, answers, anchor)
  if (step === 3) return finishQuestion(lang, category, answers, lead)

  return {
    prompt: it
      ? "Ultima cosa: questo segno deve essere un sussurro o una dichiarazione?"
      : "Last one: should this mark be a whisper or a statement?",
    options: [
      {
        label: it ? "Un sussurro: lo saprò solo io" : "A whisper, only I will know",
        weights: { intimate: 1 },
        tag: { visibility: "hidden" },
      },
      {
        label: it ? "Un dettaglio piccolo, da scoprire" : "A small detail, to be discovered",
        weights: { road: 1 },
        tag: { visibility: "small" },
      },
      {
        label: it ? "Una dichiarazione, da mostrare" : "A statement, made to be seen",
        weights: { artistic: 1 },
        tag: { visibility: "bold" },
      },
    ],
  }
}

// ---- the Tokyo path: hand-written questions, one echo line after each answer.

const tokyoCraftLabel: Partial<Record<CraftKey, [string, string]>> = {
  neon: ["Neon brush strokes", "Pennellate al neon"],
  foil: ["Metallic foil lines", "Linee di foil metallico"],
  crystal: ["Glitter and crystals", "Glitter e cristalli"],
  marker: ["Marker lettering", "Lettere a pennarello"],
  ink: ["Ink notes", "Appunti a inchiostro"],
  graffiti: ["Graffiti doodles", "Doodle da graffiti"],
  stamp: ["A travel stamp", "Un timbro di viaggio"],
  ticket: ["A ticket-date mark", "Una data da biglietto"],
  patch: ["A stitched patch", "Una toppa cucita"],
}
const tokyoCrafts: Record<ConceptKey, CraftKey[]> = {
  neon: ["neon", "foil", "crystal"],
  street: ["marker", "ink", "graffiti"],
  keepsake: ["stamp", "ticket", "patch"],
}
const tokyoEchoConcept: Record<ConceptKey, [string, string]> = {
  neon: ["The glow, then. I can almost see it reflected in the wet street.", "Il bagliore, allora. Quasi lo vedo riflesso sulla strada bagnata."],
  street: ["The signs, then. Letters you couldn't read, and still understood.", "Le insegne, allora. Lettere che non sapevi leggere, e capivi lo stesso."],
  keepsake: ["A small thing you kept. Those are the ones that matter most.", "Una piccola cosa che hai tenuto. Sono quelle che contano di più."],
}
const tokyoEchoTone: Record<ToneKey, [string, string]> = {
  energy: ["Wonder. That's the hardest thing to keep, so let's give it a place to live.", "Stupore. È la cosa più difficile da conservare, diamole un posto dove vivere."],
  free: ["Freedom. Nobody knew you, and that made you lighter.", "Libertà. Nessuno ti conosceva, e questo ti rendeva più leggera."],
  warm: ["Belonging. In the one place you thought you'd be a stranger.", "Appartenenza. Nel posto in cui pensavi di essere una straniera."],
}
const tokyoEchoFinish: Record<FinishKey, [string, string]> = {
  worn: ["Then this should look like it has already been on a few trips.", "Allora dovrebbe sembrare già stato in qualche viaggio."],
  lived: ["Pages full of scribbles. Then it should feel softly written-in.", "Pagine piene di scarabocchi. Allora dovrebbe sembrare scritto con dolcezza."],
  clean: ["Small, precise things. Then every detail should stay crisp.", "Cose piccole e precise. Allora ogni dettaglio deve restare nitido."],
}
const tokyoEchoCraft: Record<CraftKey, [string, string]> = {
  neon: ["Neon, painted by hand, a little imperfect. Just right.", "Neon dipinto a mano, un po' imperfetto. Perfetto."],
  foil: ["Thin lines of metal, like a sign catching the light.", "Sottili linee di metallo, come un'insegna che cattura la luce."],
  crystal: ["Tiny points of light, like a city seen from above.", "Piccoli punti di luce, come una città vista dall'alto."],
  marker: ["Hand-lettered, like a sign in a back street.", "Lettere a mano, come un'insegna in una via secondaria."],
  ink: ["Quiet ink, the way a note is written on a train.", "Inchiostro silenzioso, come un appunto scritto in treno."],
  graffiti: ["Quick lines, as if drawn while walking.", "Linee veloci, come disegnate camminando."],
  stamp: ["A stamp, proof that you were really there.", "Un timbro, la prova che c'eri davvero."],
  ticket: ["A date, kept like a ticket in a pocket.", "Una data, tenuta come un biglietto in tasca."],
  patch: ["Thread and fabric, stitched by hand, like a souvenir.", "Filo e tessuto, cuciti a mano, come un souvenir."],
  thread: ["", ""], paint: ["", ""], spray: ["", ""], brush: ["", ""], charm: ["", ""],
}

const tokyoQuestion = (step: number, lang: Lang, category: Category, answers: Tag): Question => {
  const i = lang === "it" ? 1 : 0
  if (step === 0)
    return {
      prompt: ["When you close your eyes and you're back in that street, what do you see first?", "Quando chiudi gli occhi e sei di nuovo in quella strada, cosa vedi per primo?"][i],
      options: [
        { label: ["The neon, glowing in the rain", "Il neon, che brilla sotto la pioggia"][i], weights: { artistic: 2 }, tag: { concept: "neon" } },
        { label: ["The signs, the handwriting, the notes", "Le insegne, le scritte, gli appunti"][i], weights: { road: 2 }, tag: { concept: "street" } },
        { label: ["A small thing I kept: a ticket, a stamp", "Una piccola cosa che ho tenuto: un biglietto, un timbro"][i], weights: { intimate: 2 }, tag: { concept: "keepsake" } },
      ],
    }
  if (step === 1)
    return {
      lead: tokyoEchoConcept[answers.concept ?? "neon"][i],
      prompt: ["You were lost, but you felt welcomed. Which feeling was stronger?", "Eri persa, ma ti sentivi accolta. Quale sensazione era più forte?"][i],
      options: [
        { label: ["Wonder, like a child again", "Stupore, di nuovo bambina"][i], weights: { artistic: 1 }, tag: { tone: "energy" } },
        { label: ["Freedom, nobody knew me", "Libertà, nessuno mi conosceva"][i], weights: { road: 1 }, tag: { tone: "free" } },
        { label: ["Belonging, somehow I fit", "Appartenenza, in qualche modo ci stavo"][i], weights: { intimate: 1 }, tag: { tone: "warm" } },
      ],
    }
  if (step === 2)
    return {
      lead: tokyoEchoTone[answers.tone ?? "energy"][i],
      prompt: ["When you travel, what do you always bring back?", "Quando viaggi, cosa riporti sempre con te?"][i],
      options: [
        { label: ["Worn, well-travelled things", "Cose consumate, che hanno viaggiato"][i], weights: { road: 1 }, tag: { finish: "worn" } },
        { label: ["A notebook full of scribbles", "Un quaderno pieno di scarabocchi"][i], weights: { intimate: 1 }, tag: { finish: "lived" } },
        { label: ["Small objects: tickets, charms", "Piccoli oggetti: biglietti, charm"][i], weights: { artistic: 1 }, tag: { finish: "clean" } },
      ],
    }
  if (step === 3)
    return {
      lead: tokyoEchoFinish[answers.finish ?? "worn"][i],
      prompt: ["How should that wonder show up on the shoe?", "Come dovrebbe apparire quello stupore sulla scarpa?"][i],
      options: tokyoCrafts[answers.concept ?? "neon"].map((key) => ({
        label: tokyoCraftLabel[key]![i],
        weights: craftWeights[key],
        tag: { craft: key },
      })),
    }
  return {
    lead: answers.craft ? tokyoEchoCraft[answers.craft][i] : undefined,
    prompt: [
      "Which personal touches should your Dream Maker add?",
      "Quali tocchi personali dovrebbe aggiungere il tuo Dream Maker?",
    ][i],
    options: (Object.keys(touchLabels) as TouchKey[]).map((key) => ({
      label: touchLabels[key].option[i],
      weights: {},
      tag: { touches: [key] },
    })),
  }
}

// ---- taste questions: they branch on what the person has already chosen and
// speak the language of Golden Goose personalization (hand lettering, doodles,
// paint, crystals, foil, patches and charms, and the signature worn-in finish).

const craftLabels: Record<CraftKey, [string, string]> = {
  ink: ["Fine ink, a quiet handwriting", "Inchiostro sottile, una scrittura silenziosa"],
  marker: ["Bold marker, big hand-drawn letters", "Pennarello deciso, grandi lettere a mano"],
  thread: ["Hand embroidery, stitched in thread", "Ricamo a mano, cucito a filo"],
  paint: ["Hand-painted colour blocks", "Blocchi di colore dipinti a mano"],
  spray: ["Spray and stencil, street style", "Spray e stencil, stile street"],
  stamp: ["A small stamp, like a seal", "Un piccolo timbro, come un sigillo"],
  brush: ["Loose brushstrokes and doodles", "Pennellate libere e doodle"],
  crystal: ["Crystals and glitter that catch the light", "Cristalli e glitter che catturano la luce"],
  foil: ["Metallic foil and neon accents", "Foil metallico e dettagli neon"],
  charm: ["A little charm or pin to carry", "Un piccolo charm o una spilla da portare"],
  neon: ["Neon brush strokes, hand-painted", "Pennellate al neon, dipinte a mano"],
  graffiti: ["Quick graffiti-style doodles", "Doodle veloci in stile graffiti"],
  ticket: ["A ticket-style date mark", "Una data in stile biglietto"],
  patch: ["A small hand-stitched patch", "Una piccola toppa cucita a mano"],
}
const craftWeights: Record<CraftKey, Partial<AxisScores>> = {
  ink: { intimate: 1 }, thread: { intimate: 1 }, stamp: { intimate: 1 },
  marker: { road: 1 }, spray: { road: 1 }, paint: { road: 1 }, charm: { road: 1 },
  brush: { artistic: 1 }, crystal: { artistic: 1 }, foil: { artistic: 1 },
  neon: { artistic: 1 }, graffiti: { road: 1 }, ticket: { intimate: 1 }, patch: { intimate: 1 },
}
const craftOption = (lang: Lang, key: CraftKey): Option => ({
  label: craftLabels[key][lang === "it" ? 1 : 0],
  weights: craftWeights[key],
  tag: { craft: key },
})

// Which hand, which material: the choices depend on the mark picked first.
const craftsFor = (motif: MotifKey | undefined, category: Category): CraftKey[] => {
  const base: Record<MotifKey, CraftKey[]> = {
    name: ["ink", "marker", "thread"],
    date: ["stamp", "thread", "charm"],
    place: ["paint", "spray", "brush"],
    feeling: ["brush", "crystal", "foil"],
  }
  const list = [...base[motif ?? "name"]]
  // A jacket or a bag can carry thread and charms better than a shoe can.
  if (category === "Shoe" && list.includes("thread")) list[list.indexOf("thread")] = "ink"
  return Array.from(new Set(list))
}

const craftQuestion = (
  lang: Lang,
  category: Category,
  answers: Tag,
  anchor?: string,
): Question => {
  const it = lang === "it"
  const motif = answers.motif
  const echo: Record<MotifKey, [string, string]> = {
    name: ["A name, then. Whose hand should write it?", "Un nome, allora. Quale mano dovrebbe scriverlo?"],
    date: ["A date, kept quiet. How should it be marked?", "Una data, discreta. Come dovrebbe essere segnata?"],
    place: [
      anchor ? `The colours of “${anchor}”. How should they be laid down?` : "The colours of that place. How should they be laid down?",
      anchor ? `I colori di “${anchor}”. Come dovrebbero essere stesi?` : "I colori di quel luogo. Come dovrebbero essere stesi?",
    ],
    feeling: ["A free gesture. Which material should carry it?", "Un gesto libero. Quale materiale dovrebbe portarlo?"],
  }
  const prompt = echo[motif ?? "name"][it ? 1 : 0]
  return {
    prompt,
    options: craftsFor(motif, category).map((key) => craftOption(lang, key)),
  }
}

const finishQuestion = (
  lang: Lang,
  category: Category,
  answers: Tag,
  lead: Axis,
): Question => {
  const it = lang === "it"
  const noun: Record<Category, [string, string]> = {
    Shoe: ["these shoes", "queste scarpe"],
    Bag: ["this bag", "questa borsa"],
    Jacket: ["this jacket", "questa giacca"],
    Boots: ["these boots", "questi stivali"],
  }
  const n = noun[category][it ? 1 : 0]
  const opts: Record<FinishKey, Option> = {
    clean: {
      label: it ? "Impeccabile, come appena nata" : "Pristine, as if just born",
      weights: { artistic: 1 },
      tag: { finish: "clean" },
    },
    lived: {
      label: it ? "Vissuta con dolcezza, già tua" : "Softly lived-in, already yours",
      weights: { intimate: 1 },
      tag: { finish: "lived" },
    },
    worn: {
      label: it ? "Consumata, come se avesse viaggiato" : "Fully worn, as if it had travelled",
      weights: { road: 1 },
      tag: { finish: "worn" },
    },
  }
  // The most likely answer comes first, shaped by the feeling and the story.
  const first: FinishKey =
    answers.tone === "free" || lead === "road"
      ? "worn"
      : answers.tone === "energy" || lead === "artistic"
        ? "clean"
        : "lived"
  const order = [first, ...(["lived", "worn", "clean"] as FinishKey[]).filter((k) => k !== first)]
  return {
    prompt: it
      ? `Quanto tempo dovrebbe già portare addosso ${n}? Il segno di vissuto è la nostra firma.`
      : `How much time should ${n} already carry? The worn-in look is our signature.`,
    options: order.map((k) => opts[k]),
  }
}

// What a typed answer says about the mark, the feeling or the visibility.
const tagPatterns: { [K in keyof Tag]-?: Record<string, RegExp> } = {
  visibility: {
    hidden: /nascost|segret|sussurr|solo io|privat|dentro|intern|hidden|secret|whisper|only i|inside|private/i,
    bold: /visibil|grande|mostr|dichiaraz|in vista|bold|loud|big|statement|show|everyone|seen/i,
    small: /piccol|dettagli|scopr|small|detail|subtle|discreet|discover/i,
  },
  tone: {
    warm: /calore|casa|famigli|abbracc|caldo|warm|home|cozy|comfort|hug/i,
    free: /libert|aria|viaggio|vento|apert|free|open|wind|travel|road/i,
    energy: /energia|festa|gioia|esplo|forza|energy|party|joy|burst|power|wild/i,
  },
  concept: {
    neon: /neon|luci|bagliore|glow|lights/i,
    street: /insegn|scritt|appunti|sign|handwrit|notes/i,
    keepsake: /biglietto|timbro|ricordino|ticket|stamp|keepsake|souvenir/i,
  },
  craft: {
    ink: /inchiostr|penna|ink|pen\b/i,
    marker: /pennarell|marker/i,
    thread: /ricam|filo|cucit|embroider|thread|stitch/i,
    paint: /dipint|acquerell|paint/i,
    spray: /spray|stencil|street|graffit/i,
    stamp: /timbro|sigillo|stamp|seal/i,
    brush: /pennell|doodle|brush/i,
    crystal: /cristall|glitter|strass|crystal|sparkl/i,
    foil: /foil|metall|neon|oro|gold/i,
    charm: /charm|spill|ciondol|pin\b|badge/i,
  },
  finish: {
    worn: /consumat|usur|viaggi|worn|scuff|travel|beaten/i,
    lived: /vissut|morbid|lived|soft|broken in/i,
    clean: /impeccabil|nuov|pulit|pristine|clean|new|perfect/i,
  },
  motif: {
    name: /nome|scritt|firma|inizial|name|handwrit|signature|initials/i,
    date: /data|giorno|anno|date|day|year/i,
    place: /color|luogo|posto|mappa|coordinat|place|map|colour/i,
    feeling: /gesto|pennell|libero|macchia|gesture|brush|stroke|splash/i,
  },
}

export const tagFromText = (text: string): Tag => {
  const tag: Tag = {}
  ;(Object.keys(tagPatterns) as (keyof Tag)[]).forEach((family) => {
    const hit = Object.entries(tagPatterns[family]).find(([, pattern]) => pattern.test(text))
    if (hit) (tag as Record<string, string>)[family] = hit[0]
  })
  return tag
}

// ---------------------------------------------------------------- the idea

export const rationale = (
  lang: Lang,
  axis: Axis,
  memory: string,
  isAlternative = false,
) => {
  const q = `“${snippet(memory)}”`
  if (lang === "it") {
    if (isAlternative) {
      const alt: Record<Axis, string> = {
        intimate: "un segreto custodito, raccontato da piccoli dettagli scritti a mano",
        road: "una storia di movimento e usura, raccontata dai segni del tempo e della strada",
        artistic: "una storia vivida e libera, raccontata con colore e gesto spontanei",
      }
      return `Un altro modo di leggere ${q}: come ${alt[axis]}.`
    }
    if (axis === "intimate")
      return `Perché ${q} sembra custodito con cura, piccoli dettagli scritti a mano e segreti silenziosi lo racconteranno meglio.`
    if (axis === "road")
      return `Perché in ${q} ci sono movimento e usura, i segni del tempo e della strada lo racconteranno meglio.`
    return `Perché ${q} è vivido e libero, colore e gesto spontanei lo racconteranno meglio.`
  }
  if (isAlternative) {
    const alt: Record<Axis, string> = {
      intimate: "a quiet, kept-close secret, told through small handwritten details",
      road: "a story of movement and wear, told through the marks of time and the road",
      artistic: "a vivid, free story, told through spontaneous colour and expression",
    }
    return `Another way to read ${q}: as ${alt[axis]}.`
  }
  if (axis === "intimate")
    return `Because ${q} feels kept close, small handwritten details and quiet secrets will carry it best.`
  if (axis === "road")
    return `Because ${q} has movement and wear in it, the marks of time and the road will carry it best.`
  return `Because ${q} feels vivid and free, spontaneous colour and expression will carry it best.`
}

const touchLabels: Record<TouchKey, { option: [string, string]; brief: [string, string] }> = {
  words: {
    option: ["Hand-lettered words", "Parole scritte a mano"],
    brief: ["Hand-lettered or embroidered words", "Parole scritte a mano o ricamate"],
  },
  drawing: {
    option: ["A hand-drawn illustration", "Un'illustrazione disegnata a mano"],
    brief: ["A hand-drawn illustration", "Un'illustrazione disegnata a mano"],
  },
  sparkle: {
    option: ["Crystals or studs", "Cristalli o borchie"],
    brief: ["Crystals or studs", "Cristalli o borchie"],
  },
  accessory: {
    option: ["A charm or a patch", "Un charm o una toppa"],
    brief: ["A charm or a patch", "Un charm o una toppa"],
  },
}

// Where the mark sits is decided with the Dream Maker, so the sheet only states how
// visible it should be, never a specific spot.
const visibilityText: Record<Visibility, [string, string]> = {
  bold: ["Large and visible, made to be seen", "Grande e visibile, fatto per essere mostrato"],
  small: ["A small detail, discovered up close", "Un dettaglio piccolo, da scoprire da vicino"],
  hidden: ["Discreet, a mark only the wearer knows", "Discreto, un segno che conosce solo chi lo indossa"],
}

// A concrete first idea: what the mark is, its colours, finish and position.
export const buildBrief = (input: {
  lang: Lang
  category: Category
  axis: Axis
  entities: Entities
  answers: Tag
  memory?: string
}): Brief => {
  const { lang, category, axis, entities, answers } = input
  const it = lang === "it"
  const motifKey = answers.motif ?? axisMotif[axis]
  const toneKey = answers.tone ?? axisTone[axis]
  const visibility = answers.visibility ?? axisVisibility[axis]

  const motifs: Record<MotifKey, string> = {
    name: it ? "Parole scritte a mano" : "Hand-lettered words",
    place: entities.place
      ? it
        ? `I colori e l'atmosfera di “${entities.place}”`
        : `The colours and mood of “${entities.place}”`
      : it
        ? "I colori di quel luogo"
        : "The colours of that place",
    date: it ? "Un segno piccolo e discreto" : "A small, quiet mark",
    feeling: entities.feeling
      ? it
        ? `Un gesto di colore libero per “${entities.feeling}”`
        : `A free gesture of colour for “${entities.feeling}”`
      : it
        ? "Un gesto di colore libero"
        : "A free gesture of colour",
  }
  const palettes: Record<ToneKey, [string, string]> = {
    warm: ["Cream, faded gold, terracotta", "Crema, oro sbiadito, terracotta"],
    free: ["Dusty blue, sand, optical white", "Azzurro polvere, sabbia, bianco ottico"],
    energy: ["Vivid red, foil, neon accents", "Rosso vivo, foil, dettagli neon"],
  }
  const finishesByAxis: Record<Axis, [string, string]> = {
    intimate: ["Aged leather, burnished edges", "Pelle invecchiata, bordi bruniti"],
    road: ["Scuffs, wear, cracked paint", "Graffi, usura, vernice screpolata"],
    artistic: ["Full colour, glitter, brushstrokes", "Colore pieno, glitter, pennellate"],
  }
  const finishes: Record<FinishKey, [string, string]> = {
    clean: ["Pristine, clean surfaces, crisp edges", "Impeccabile, superfici pulite, bordi netti"],
    lived: ["Softly lived-in, burnished edges", "Vissuta con dolcezza, bordi bruniti"],
    worn: ["Fully worn: scuffs, cracks, travelled", "Consumata: graffi, crepe, viaggiata"],
  }
  const craftKey: CraftKey | undefined = answers.craft
  const technique = craftKey
    ? (input.memory && isTokyoStory(input.memory ?? "") ? tokyoCraftLabel[craftKey] : undefined)?.[it ? 1 : 0] ??
      craftLabels[craftKey][it ? 1 : 0]
    : (["ink", "paint", "brush"] as CraftKey[]).map((k) => craftLabels[k][it ? 1 : 0])[
        ["intimate", "road", "artistic"].indexOf(axis)
      ]
  const concept = input.memory && isTokyoStory(input.memory) ? answers.concept : undefined
  const tokyoMotif: Record<ConceptKey, [string, string]> = {
    neon: ["The neon glow of Shinjuku in the rain", "Il bagliore al neon di Shinjuku sotto la pioggia"],
    street: ["Street-sign lettering and handwritten notes from Tokyo", "Lettere di insegne e appunti scritti a mano a Tokyo"],
    keepsake: ["A small keepsake of the trip, stamped or lettered by hand", "Un piccolo ricordo del viaggio, timbrato o scritto a mano"],
  }
  const tokyoPalette: Record<ConceptKey, [string, string]> = {
    neon: ["Electric pink, blue, warm orange", "Rosa elettrico, blu, arancio caldo"],
    street: ["Black ink on white, a touch of red", "Inchiostro nero su bianco, un tocco di rosso"],
    keepsake: ["Cream, stamp red, faded ink", "Crema, rosso timbro, inchiostro sbiadito"],
  }
  return {
    motif: concept ? tokyoMotif[concept][it ? 1 : 0] : motifs[motifKey],
    palette: concept ? tokyoPalette[concept][it ? 1 : 0] : palettes[toneKey][it ? 1 : 0],
    technique,
    finish: answers.finish ? finishes[answers.finish][it ? 1 : 0] : finishesByAxis[axis][it ? 1 : 0],
    placement: visibilityText[visibility][it ? 1 : 0],
    touches: answers.touches?.length
      ? answers.touches.map((key) => touchLabels[key].brief[it ? 1 : 0]).join(" · ")
      : undefined,
  }
}

// Link of the purchase flow behind "Book an appointment". Leave empty until
// the booking URL is available; the button then does nothing but log a hint.
export const bookingUrl = ""

// One extra question after "Show me another reading": what felt off, and where to go instead.
export const refineQuestion = (lang: Lang, current: Axis): Question => {
  const it = lang === "it"
  const options: Record<Axis, string> = {
    intimate: it ? "Più personale e silenzioso: piccoli dettagli solo per me" : "More personal and quiet: small details only I would notice",
    road: it ? "Più vissuto: consumato, viaggiato, pieno di segni del tempo" : "More lived-in: worn, travelled, full of marks of time",
    artistic: it ? "Più audace: più colore, gesto ed espressione" : "Bolder: more colour, gesture and expression",
  }
  return {
    prompt: it ? "Cosa non ti convince? Dimmi dove vuoi andare." : "What didn't feel right? Tell me where you'd rather go.",
    options: (["intimate", "road", "artistic"] as Axis[])
      .filter((axis) => axis !== current)
      .map((axis) => ({ label: options[axis], weights: { [axis]: 3 } as Partial<AxisScores> })),
  }
}
