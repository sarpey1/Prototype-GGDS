import { useEffect, useRef } from "react"
import lottie from "lottie-web/build/player/lottie_light"
import starAnimation from "./assets/star-animation.json"

// The hand-drawn star shown while the matching images are being set.
export default function LoadingStar() {
  const hostRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    const host = hostRef.current
    if (!host) return
    const reduceMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches
    const animation = lottie.loadAnimation({
      container: host,
      renderer: "svg",
      loop: !reduceMotion,
      autoplay: !reduceMotion,
      animationData: starAnimation,
      rendererSettings: { preserveAspectRatio: "xMidYMid meet" },
    })
    // With reduced motion, show the finished star instead of animating.
    if (reduceMotion) animation.goToAndStop(49, true)
    return () => animation.destroy()
  }, [])

  return <div className="loading-star" ref={hostRef} aria-hidden="true" />
}
