// Stand-in for the "framer" package, which only exists inside Framer. The
// Folder component calls these for its property panel; here they do nothing.
export const ControlType = {
  Color: "color",
  Number: "number",
  Boolean: "boolean",
  Image: "image",
} as const

export function addPropertyControls(_component: unknown, _controls: unknown) {}
