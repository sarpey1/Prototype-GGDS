// Adaptive chat layer. Uses the artifact "sample" capability (Claude, on the viewer's
// own account) to read the story and ask aimed questions. At most three calls per
// session. Anything missing or failing returns null so the scripted flow takes over.

import type { Axis, Visibility } from "./conversation"

export const vocab = [
  "lettering", "initials", "illustration", "crystals", "pins", "fringe", "distressed",
  "graffiti", "emboss", "embroidery",
  "star", "heart", "roses", "wings", "symbols", "text",
  "quiet", "playful", "bold", "wild",
] as const
export type AiTag = (typeof vocab)[number]

export type AiOption = { label: string; tags: AiTag[] }
export type AiQuestion = { prompt: string; options: AiOption[] }
export type AiBrief = {
  motif?: string
  palette?: string
  technique?: string
  finish?: string
  touches?: string
}
export type AiLogEntry = { prompt: string; answer: string }

type SampleFn = ((input: string, opts?: Record<string, unknown>) => Promise<{ text: string }>) & {
  json: <T = unknown>(input: string, opts?: Record<string, unknown>) => Promise<T>
}

let samplePromise: Promise<SampleFn | null> | null = null
export const getSample = (): Promise<SampleFn | null> => {
  if (samplePromise) return samplePromise
  const claude = (window as unknown as { claude?: { use?: (n: string) => Promise<unknown> } }).claude
  samplePromise =
    claude?.use ? claude.use("sample").then((s) => (s as SampleFn) ?? null).catch(() => null) : Promise.resolve(null)
  return samplePromise
}

// What the Dream Makers can really do, per product, taken from the archive itself.
export type Catalogue = Record<string, string[]>

const clean = (value: unknown, max = 90) =>
  typeof value === "string" ? value.replace(/\s+/g, " ").trim().slice(0, max) : ""

const cleanTags = (value: unknown): AiTag[] =>
  Array.isArray(value)
    ? (value.filter((t) => typeof t === "string" && (vocab as readonly string[]).includes(t)) as AiTag[])
    : []

const cleanQuestion = (value: unknown): AiQuestion | null => {
  const q = value as { prompt?: unknown; options?: unknown }
  const prompt = clean(q?.prompt, 140)
  if (!prompt || !Array.isArray(q.options)) return null
  const options = q.options
    .map((o: { label?: unknown; tags?: unknown }) => ({ label: clean(o?.label, 56), tags: cleanTags(o?.tags) }))
    .filter((o: AiOption) => o.label)
    .slice(0, 4)
  return options.length >= 2 ? { prompt, options } : null
}

const grounding = (category: string, catalogue: Catalogue) =>
  `The product is: ${category}. Real personalizations Dream Makers have made on this kind of product:\n- ${(catalogue[category] ?? []).join("\n- ")}\n` +
  `Tag vocabulary (use ONLY these words in "tags"): ${vocab.join(", ")}.\n` +
  `Never invent techniques, materials or placements outside what the list above shows. Do not ask where on the product a mark goes: that is decided with the Dream Maker. Never suggest, ask for or offer examples of what any written text should say (no names, dates, mottos or quotes): options describe only the visual treatment (technique, mood, look), and the words are left to the person and their Dream Maker.`

const run = async <T>(prompt: string, signal?: AbortSignal, tier?: string): Promise<T | null> => {
  const sample = await getSample()
  if (!sample) return null
  try {
    return await sample.json<T>(prompt, { cache: false, signal, ...(tier ? { modelTier: tier } : {}) })
  } catch (e) {
    console.warn("sample failed", (e as { code?: string })?.code)
    return null
  }
}

// Call 1: read the story, reflect it back, ask the first aimed question.
export const analyzeStory = async (
  story: string,
  category: string,
  catalogue: Catalogue,
  signal?: AbortSignal,
): Promise<{ reflection: string[]; reading: string; question: AiQuestion } | null> => {
  const r = await run<{ reflection?: unknown; reading?: unknown; question?: unknown }>(
    `You are the warm, perceptive guide of Golden Goose "Dream Makers", artisans who hand-personalize sneakers, bags, boots and jackets. A customer shared a memory they want to keep. Understand what this specific story says about their visual taste.

STORY:
"""${story.slice(0, 600)}"""

${grounding(category, catalogue)}

Reply with ONLY JSON:
{"reflection": [3 short lines, each under 70 characters: what you heard (name a concrete detail from THEIR story), what it feels like, what you want to ask next],
 "reading": "one sentence, for yourself, about their visual taste and what is still unclear",
 "question": {"prompt": "ONE question under 110 characters that refers to a concrete detail of their story and clarifies their taste, e.g. how the memory would look as a mark",
              "options": [3 or 4 of {"label": "under 50 characters, a distinct visual direction", "tags": [1-3 vocabulary words]}]}}
Write everything in the language of the story. Be specific to this story, never generic.`,
    signal,
  )
  const question = cleanQuestion(r?.question)
  const reflection = Array.isArray(r?.reflection) ? r.reflection.map((l) => clean(l, 90)).filter(Boolean).slice(0, 3) : []
  if (!question || reflection.length < 2) return null
  return { reflection, reading: clean(r?.reading, 240), question }
}

// Call 2: after the first answer, two more questions that dig where the story is still vague.
export const followUps = async (
  story: string,
  reading: string,
  log: AiLogEntry[],
  category: string,
  catalogue: Catalogue,
  signal?: AbortSignal,
): Promise<AiQuestion[] | null> => {
  const r = await run<{ questions?: unknown }>(
    `You guide a customer of Golden Goose "Dream Makers" toward the personalization of their ${category}.

STORY: """${story.slice(0, 600)}"""
YOUR READING: ${reading}
SO FAR:
${log.map((l) => `Q: ${l.prompt}\nA: ${l.answer}`).join("\n")}

${grounding(category, catalogue)}

Write the next TWO questions. Question 1 builds directly on their last answer and drills into the one detail still unclear (what the mark shows, which words, which motif). Question 2 explores a different dimension of taste: mood and how loud or discreet the result should feel. Each refers to their story.
Reply with ONLY JSON: {"questions": [{"prompt": "under 110 characters", "options": [3 or 4 of {"label": "under 50 characters", "tags": [1-3 vocabulary words]}]}, {...}]}
Same language as the story.`,
    signal,
  )
  const qs = Array.isArray(r?.questions) ? r.questions.map(cleanQuestion).filter((q): q is AiQuestion => !!q) : []
  return qs.length >= 2 ? qs.slice(0, 2) : null
}

// Call 3: turn the whole conversation into a direction, image tags and a concept brief.
export const conclude = async (
  story: string,
  reading: string,
  log: AiLogEntry[],
  tagsSoFar: AiTag[],
  category: string,
  catalogue: Catalogue,
  signal?: AbortSignal,
  rejected?: { axis: Axis; tags: AiTag[] },
): Promise<{ axis: Axis; tags: AiTag[]; visibility: Visibility; rationale: string; brief: AiBrief } | null> => {
  const r = await run<{
    axis?: string
    tags?: unknown
    visibility?: string
    rationale?: unknown
    brief?: Record<string, unknown>
  }>(
    `You guide a customer of Golden Goose "Dream Makers" toward the personalization of their ${category}.

STORY: """${story.slice(0, 600)}"""
YOUR READING: ${reading}
CONVERSATION:
${log.map((l) => `Q: ${l.prompt}\nA: ${l.answer}`).join("\n")}
Tags from their choices: ${tagsSoFar.join(", ") || "none"}
${rejected ? `The person was shown a reading (direction ${rejected.axis}, tags ${rejected.tags.join(", ")}) and asked for another one. Use their latest answer to find a clearly different direction.\n` : ""}
${grounding(category, catalogue)}

Conclude. Reply with ONLY JSON:
{"axis": "intimate" (kept-close, handwritten, personal) | "road" (movement, wear, travel) | "artistic" (colour, gesture, expression),
 "tags": [3 to 6 vocabulary words describing the coherent set of works to show them],
 "visibility": "hidden" | "small" | "bold",
 "rationale": "one sentence beginning with Because, quoting a detail of their story",
 "brief": {"motif": "what the mark shows", "palette": "colours drawn from their story", "technique": "how a Dream Maker would make it", "finish": "the surface feel", "touches": "extra personal touches, or empty"}}
Each brief value under 80 characters, concrete, only techniques visible in the list above. Same language as the story.`,
    signal,
  )
  if (!r) return null
  const axis = (["intimate", "road", "artistic"] as const).find((a) => a === r.axis)
  const tags = cleanTags(r.tags)
  const rationale = clean(r.rationale, 240)
  if (!axis || tags.length === 0 || !rationale) return null
  const visibility = (["hidden", "small", "bold"] as const).find((v) => v === r.visibility) ?? "small"
  const b = r.brief ?? {}
  return {
    axis,
    tags,
    visibility,
    rationale,
    brief: {
      motif: clean(b.motif, 100) || undefined,
      palette: clean(b.palette, 100) || undefined,
      technique: clean(b.technique, 100) || undefined,
      finish: clean(b.finish, 100) || undefined,
      touches: clean(b.touches, 100) || undefined,
    },
  }
}

// Call 4 (after pinning): the two texts of the concept sheet, matched to the chosen works.
export const writeSheet = async (
  story: string,
  reading: string,
  brief: AiBrief,
  works: string[],
  category: string,
  signal?: AbortSignal,
): Promise<{ summary: string; style: string } | null> => {
  const r = await run<{ summary?: unknown; style?: unknown }>(
    `A customer of Golden Goose "Dream Makers" is preparing a concept sheet for their ${category}, to show a Dream Maker as a conversation starter.

STORY: """${story.slice(0, 600)}"""
YOUR READING: ${reading || "n/a"}
FIRST IDEA: ${Object.values(brief).filter(Boolean).join("; ")}
WORKS THEY CHOSE (the kind of personalization they want):
- ${works.join("\n- ")}

Reply with ONLY JSON: {"summary": "a recap of their story in at most 250 characters, warm, speaking to the person (you)", "style": "at most 150 characters on the visual possibilities to express their story, matching the kinds of personalization of the chosen works; name only techniques visible in those works; never suggest what any written text should say"}
Same language as the story.`,
    signal,
    "quick",
  )
  const summary = clean(r?.summary, 250)
  const style = clean(r?.style, 150)
  return summary && style ? { summary, style } : null
}

// After "show me another reading": one question about what felt off and where to go instead.
export const refineAsk = async (
  story: string,
  reading: string,
  log: AiLogEntry[],
  shown: { axis: Axis; tags: AiTag[]; summary: string },
  category: string,
  catalogue: Catalogue,
  signal?: AbortSignal,
): Promise<AiQuestion | null> => {
  const r = await run<{ question?: unknown }>(
    `You guide a customer of Golden Goose "Dream Makers" toward the personalization of their ${category}.

STORY: """${story.slice(0, 600)}"""
YOUR READING: ${reading}
CONVERSATION:
${log.map((l) => `Q: ${l.prompt}\nA: ${l.answer}`).join("\n")}
THE READING YOU JUST SHOWED (they asked for another one): ${shown.summary} (direction ${shown.axis}, tags ${shown.tags.join(", ")})

${grounding(category, catalogue)}

Ask ONE question that finds out what did not feel right and where their taste really lies. Offer 3 or 4 options that are clearly different from the rejected reading.
Reply with ONLY JSON: {"question": {"prompt": "under 110 characters", "options": [{"label": "under 50 characters", "tags": [1-3 vocabulary words]}]}}
Same language as the story.`,
    signal,
  )
  return cleanQuestion(r?.question)
}
