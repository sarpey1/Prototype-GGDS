import { useEffect, useRef, useState } from "react"
import { createPortal } from "react-dom"
import {
  analyzeStory,
  conclude,
  followUps,
  getSample,
  refineAsk,
  writeSheet,
  type AiBrief,
  type AiLogEntry,
  type AiQuestion,
  type AiTag,
  type Catalogue,
} from "./adaptive"
import catalog from "./data/golden-goose-cocreation-catalog.csv?raw"
import {
  addScores,
  bookingUrl,
  buildBrief,
  detectLang,
  directionLabel,
  emptyScores,
  extractEntities,
  getQuestion,
  sampleStories,
  hasSignal,
  isThinStory,
  nudgeLine,
  rankAxes,
  rationale as buildRationale,
  reflectionLines,
  refineQuestion,
  scoreText,
  tagFromText,
  totalQuestions,
  ui,
  type Axis,
  type AxisScores,
  type Brief,
  type Entities,
  type Lang,
  type Question,
  type Tag,
} from "./conversation"
import Checkout from "./Checkout"
import { clip, downloadBlob, renderConceptSheet } from "./storyCardFile"
import { ProductDrawer } from "./ProductDrawer"
import Folder from "./Folder"
import LoadingStar from "./LoadingStar"
import conceptSheet from "./assets/concept-sheet.png"
import folderSymbol from "./assets/folder-symbol.svg"
import { defaultProductId, products, type Product } from "./products"

type Card = {
  id: number
  left: number
  top: number
  rotation: number
  scale?: number
  delay: number
  duration: number
  image: string
  alt: string
  category: string
  model: string
  personalization: string
  note: string
  directions: Axis[]
  tags: string[]
}

type Point = { x: number; y: number }
type CardLayout = Omit<Card, "tags" | "image" | "alt" | "category" | "model" | "personalization" | "note">
type FlowStage = "invitation" | "memory" | "reflection" | "followup" | "thinking" | "direction" | "loading" | "pinning" | "story"
type DirectionId = "intimate" | "road" | "artistic"
type Direction = {
  id: DirectionId
  shortLabel: string
  optionCopy: string
}

const assetPathPrefix = "/assets"
const woodTexture = `${assetPathPrefix}/93916.png`
const vignette = `${assetPathPrefix}/76e6d.svg`
const goldenLightOverlay = `${assetPathPrefix}/golden-light-overlay.jpg`
const goldenGooseLogo = `${assetPathPrefix}/golden-goose-logo.png`
const closeIcon = `${assetPathPrefix}/8d2dd.svg`
const paperTexture = `${assetPathPrefix}/2909b.png`
const invitationArrow = `${assetPathPrefix}/6743f.svg`
const doneStamp = `${assetPathPrefix}/44169.svg`
const resetOval = `${assetPathPrefix}/a4a89.svg`
const fabricRolls = `${assetPathPrefix}/c9886.png`
const pencilTray = `${assetPathPrefix}/2e94a.png`
const ambientAudio = "/audio/The_Artisans_Studio.mp3"

const cardLayouts: CardLayout[] = [
  { id: 1, left: 0, top: -11.6, rotation: -11.52, delay: -1.8, duration: 8.6 },
  { id: 2, left: -6.65, top: 26, rotation: 9.48, delay: -4.2, duration: 9.8 },
  {
    id: 3,
    left: 17.12,
    top: 14.36,
    rotation: 9.48,
    delay: -6.1,
    duration: 10.4,
  },
  { id: 4, left: 25.46, top: -16, rotation: 9.48, delay: -3.3, duration: 9.1 },
  {
    id: 5,
    left: -5.86,
    top: 55.18,
    rotation: -25.16,
    delay: -7.4,
    duration: 11.2,
  },
  {
    id: 6,
    left: 24.09,
    top: 44.53,
    rotation: 0,
    scale: 0.93,
    delay: -2.5,
    duration: 8.9,
  },
  { id: 7, left: 48.18, top: 28.61, rotation: 0, delay: -5.4, duration: 10.1 },
  { id: 8, left: 57.55, top: -8.5, rotation: 0, delay: -8.2, duration: 11.4 },
  { id: 9, left: 49.87, top: 63.77, rotation: 0, delay: -3.8, duration: 9.6 },
  {
    id: 10,
    left: 72.27,
    top: 44.53,
    rotation: -10.27,
    scale: 0.85,
    delay: -6.7,
    duration: 10.8,
  },
  {
    id: 11,
    left: 74.74,
    top: -0.3,
    rotation: -10.27,
    delay: -1.2,
    duration: 9.4,
  },
  {
    id: 12,
    left: -25.2,
    top: 107.37,
    rotation: 30.48,
    delay: -4.9,
    duration: 10.6,
  },
]

const directions: Direction[] = [
  {
    id: "intimate",
    shortLabel: "Quiet, whispered secret",
    optionCopy: "A quiet, whispered secret (handwritten dates, intimate words)",
  },
  {
    id: "road",
    shortLabel: "Marks of time and the road",
    optionCopy: "The raw marks of time, asphalt, and open roads",
  },
  {
    id: "artistic",
    shortLabel: "Free, expressive art",
    optionCopy: "A free, expressive stroke of spontaneous art",
  },
]

const filteredLayouts = [
  { left: 15, top: -4, rotation: -8 },
  { left: 38, top: 13, rotation: 6 },
  { left: 55, top: 43, rotation: -5 },
  { left: -2, top: 38, rotation: 5 },
  { left: 30, top: 50, rotation: -4 },
  { left: 62, top: -8, rotation: 7 },
  { left: 74, top: 26, rotation: -6 },
  { left: -6, top: 6, rotation: -3 },
]

const parseCsvRow = (row: string) => {
  const fields: string[] = []
  let field = ""
  let quoted = false

  for (let index = 0; index < row.length; index += 1) {
    const character = row[index]
    const nextCharacter = row[index + 1]

    if (character === '"' && quoted && nextCharacter === '"') {
      field += '"'
      index += 1
    } else if (character === '"') {
      quoted = !quoted
    } else if (character === "," && !quoted) {
      fields.push(field.trim())
      field = ""
    } else {
      field += character
    }
  }

  fields.push(field.trim())
  return fields
}

const [, ...catalogRows] = catalog.trim().split(/\r?\n/)
const categoryCounts: Record<string, number> = {}
const cards: Card[] = catalogRows
  .filter((row) => row.trim())
  .map((row, index) => {
    const [image, category, model, personalization, note, directionsField, tagsField] =
      parseCsvRow(row)
    const layoutIndex = categoryCounts[category.trim()] ?? 0
    categoryCounts[category.trim()] = layoutIndex + 1
    const layout = cardLayouts[layoutIndex % cardLayouts.length]

    return {
      ...layout,
      id: index + 1,
      image: image.trim(),
      alt: `${model} ${category}`,
      category: category.trim(),
      model: model.trim(),
      personalization: personalization.trim(),
      note: note.trim(),
      // Which visual directions a reference belongs to (CSV column, separated by |).
      tags: (tagsField ?? "").split("|").map((value) => value.trim()).filter(Boolean),
      directions: (directionsField ?? "")
        .split("|")
        .map((value) => value.trim())
        .filter((value): value is Axis =>
          ["intimate", "road", "artistic"].includes(value),
        ),
    }
  })

const catalogue: Catalogue = {}
cards.forEach((card) => {
  ;(catalogue[card.category] ??= []).push(`${card.personalization} (${card.note})`)
})

const toQuestion = (q: AiQuestion): Question => ({
  prompt: q.prompt,
  options: q.options.map((o) => ({ label: o.label, weights: {}, tag: { ai: o.tags } })),
})

const cardIdsFor = (category: string) =>
  cards.filter((card) => card.category === category).map((card) => card.id)

const defaultCategory =
  products.find((product) => product.id === defaultProductId)?.category ??
  "Shoe"

const lightParticles = Array.from({ length: 24 }, (_, index) => ({
  left: (index * 37 + 11) % 97,
  top: (index * 53 + 7) % 94,
  size: 2 + (index % 4) * 0.8,
  delay: -(index % 9) * 1.7,
  duration: 10 + (index % 7) * 1.4,
  drift: 10 + (index % 5) * 5,
}))

const entranceDirections = [
  { x: "-48vw", y: "0" },
  { x: "0", y: "-54vh" },
  { x: "46vw", y: "0" },
  { x: "0", y: "54vh" },
  { x: "-38vw", y: "-38vh" },
  { x: "38vw", y: "38vh" },
]

function PolaroidFrame({
  image,
  alt,
  personalization,
}: Pick<Card, "image" | "alt" | "personalization">) {
  const hasLongPersonalization = personalization.length > 32

  return (
    <div className="polaroid" data-node-id="11:197">
      <div className="photo-slot" data-node-id="11:198">
        <img src={image} alt={alt} draggable="false" />
      </div>
      <p
        className={`personalization${
          hasLongPersonalization ? " personalization-long" : ""
        }`}
        data-node-id="11:199"
      >
        {personalization}
      </p>
    </div>
  )
}

const briefRows = (lang: Lang, brief: Brief | null) => {
  if (!brief) return []
  const labels = ui(lang).briefLabels
  return [
    { label: labels.motif, text: brief.motif },
    { label: labels.palette, text: brief.palette },
    { label: labels.technique, text: brief.technique },
    { label: labels.finish, text: brief.finish },
    ...(brief.touches ? [{ label: labels.touches, text: brief.touches }] : []),
    { label: labels.placement, text: brief.placement },
  ]
}

function FinalStep({
  lang,
  memory,
  brief,
  pinnedCards,
  product,
  onWriteSheet,
}: {
  lang: Lang
  memory: string
  brief: Brief | null
  pinnedCards: Card[]
  product: Product
  onWriteSheet: (works: string[]) => Promise<{ summary: string; style: string } | null>
}) {
  const t = ui(lang)
  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved">("idle")
  const [toast, setToast] = useState(false)
  const toastTimerRef = useRef<number | null>(null)
  const blobRef = useRef<Blob | null>(null)
  const [checkoutOpen, setCheckoutOpen] = useState(false)
  const [previewOpen, setPreviewOpen] = useState(false)
  const [sheetUrl, setSheetUrl] = useState<string | null>(null)
  const [sheetId] = useState(() => String(10000 + Math.floor(Math.random() * 89999)))
  // Texts are written by the plain fallback first, then replaced when Claude answers.
  const [sheetText, setSheetText] = useState(() => ({
    summary: clip(memory, 250),
    style: clip(
      [brief?.motif, brief?.technique, brief?.finish].filter(Boolean).join(". "),
      150,
    ),
  }))
  useEffect(
    () => () => {
      if (toastTimerRef.current !== null) window.clearTimeout(toastTimerRef.current)
    },
    [],
  )

  useEffect(() => {
    let dead = false
    onWriteSheet(pinnedCards.map((card) => `${card.personalization} (${card.note})`)).then(
      (result) => {
        if (!dead && result) setSheetText(result)
      },
    )
    return () => {
      dead = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const buildSheet = () =>
    renderConceptSheet({
      title: t.cardTitle,
      summary: sheetText.summary,
      styleTitle: t.sheetStyle,
      style: sheetText.style,
      images: pinnedCards.map((card) => ({ image: card.image, label: card.personalization })),
      id: sheetId,
      logo: goldenGooseLogo,
      disclaimer: t.sheetDisclaimer,
    })

  // The paper on the folder is the real, personalized sheet.
  useEffect(() => {
    let dead = false
    let url: string | null = null
    buildSheet().then((blob) => {
      if (dead || !blob) return
      blobRef.current = blob
      url = URL.createObjectURL(blob)
      setSheetUrl(url)
    })
    return () => {
      dead = true
      if (url) URL.revokeObjectURL(url)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sheetText])

  const openPreview = async () => {
    if (!blobRef.current) {
      const blob = await buildSheet()
      if (blob) {
        blobRef.current = blob
        setSheetUrl((current) => current ?? URL.createObjectURL(blob))
      }
    }
    setPreviewOpen(true)
  }

  const saveCard = async () => {
    setSaveState("saving")
    const blob = blobRef.current ?? (await buildSheet())
    if (blob) downloadBlob(blob)
    setSaveState("saved")
    setToast(true)
    if (toastTimerRef.current !== null) window.clearTimeout(toastTimerRef.current)
    toastTimerRef.current = window.setTimeout(() => setToast(false), 3500)
  }

  return (
    <div className="final-step">
      <div className="folder-wrap">
        <Folder
          color="#8F7550"
          size={2}
          cornerRadius={10}
          hoverLift
          enableMagnet
          duration={0.3}
          paper1Src={sheetUrl ?? conceptSheet} symbolSrc={folderSymbol}
        />
      </div>
      <div className="final-copy">
        <p className="flow-title">
          {t.finalReady.map((line, index) => (
            <span key={line}>
              {index > 0 && <br />}
              {line}
            </span>
          ))}
        </p>
        <p className="final-sub">{t.finalSub}</p>
      </div>
      <div className="final-actions">
        <a
          className="final-book"
          href={bookingUrl || "#checkout"}
          onClick={(event) => {
            if (!bookingUrl) {
              event.preventDefault()
              setCheckoutOpen(true)
            }
          }}
        >
          {t.finalBook}
        </a>
        <button
          className="final-save"
          type="button"
          onClick={openPreview}
        >
          {saveState === "saved" ? t.saved : t.finalSave}
        </button>
      </div>
      {previewOpen &&
        createPortal(
          <div
            className="sheet-preview"
            role="dialog"
            aria-modal="true"
            aria-label={t.cardTitle}
            onClick={() => setPreviewOpen(false)}
          >
            <button
              className="sheet-preview-close"
              type="button"
              aria-label={lang === "it" ? "Chiudi anteprima" : "Close preview"}
              onClick={() => setPreviewOpen(false)}
            >
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>
            <div className="sheet-preview-frame" onClick={(event) => event.stopPropagation()}>
              {sheetUrl && <img src={sheetUrl} alt={t.cardTitle} />}
              <button
                className="sheet-preview-save"
                type="button"
                disabled={saveState === "saving"}
                onClick={() => void saveCard()}
              >
                {saveState === "saved" ? t.saved : lang === "it" ? "Scarica l'immagine" : "Download image"}
              </button>
            </div>
          </div>,
          document.body,
        )}
      {checkoutOpen && (
        <Checkout
          lang={lang}
          product={product}
          onClose={() => setCheckoutOpen(false)}
          onDownloadSheet={async () => {
            const blob = blobRef.current ?? (await buildSheet())
            if (blob) downloadBlob(blob)
          }}
        />
      )}
      {toast &&
        createPortal(
          <div className="save-toast" role="status">
            <span className="save-toast-icon">
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M5 12.5l4.5 4.5L19 7.5" />
              </svg>
            </span>
            {t.toastSaved}
          </div>,
          document.body,
        )}
      <span className="sr-only" aria-live="polite">
        {saveState === "saved" ? t.savedSr : ""}
      </span>
    </div>
  )
}

// Types the opening lines one after the other inside the empty story box.
function useTypewriter(lines: string[], active: boolean) {
  const [text, setText] = useState("")
  const key = lines.join("|")
  useEffect(() => {
    if (!active) return
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setText(lines[0] ?? "")
      return
    }
    let line = 0
    let count = 0
    let erasing = false
    let timer = 0
    const tick = () => {
      const current = lines[line] ?? ""
      if (!erasing) {
        count += 1
        setText(current.slice(0, count))
        if (count >= current.length) {
          erasing = true
          timer = window.setTimeout(tick, 1800)
          return
        }
        timer = window.setTimeout(tick, 55)
      } else {
        count -= 1
        setText(current.slice(0, Math.max(count, 0)))
        if (count <= 0) {
          erasing = false
          line = (line + 1) % lines.length
          timer = window.setTimeout(tick, 380)
          return
        }
        timer = window.setTimeout(tick, 22)
      }
    }
    timer = window.setTimeout(tick, 500)
    return () => window.clearTimeout(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, active])
  return text
}

const storyMaxLength = 500

function CoCreationPanel({
  stage: liveStage,
  memory,
  direction: liveDirection,
  lang: liveLang,
  reflection: liveReflection,
  question: liveQuestion,
  proposal: liveProposal,
  rationale: liveRationale,
  brief: liveBrief,
  pinnedCards,
  isLoading,
  isFiltering,
  onBegin,
  onMemorySubmit,
  onAnswer,
  onShowAnother,
  busy,
  onDirectionSelect,
  onDone,
  onWriteSheet,
  product,
  onReset,
  onBack,
}: {
  stage: FlowStage
  memory: string
  direction: Direction | null
  lang: Lang
  reflection: string[]
  question: Question | null
  proposal: Direction | null
  rationale: string
  brief: Brief | null
  pinnedCards: Card[]
  isLoading: boolean
  isFiltering: boolean
  onBegin: () => void
  onMemorySubmit: (memory: string) => void
  onAnswer: (weights: Partial<AxisScores>, tag?: Tag, summary?: string) => void
  onShowAnother: () => void
  busy: boolean
  onDirectionSelect: (direction: Direction) => void
  onDone: () => void
  product: Product
  onWriteSheet: (works: string[]) => Promise<{ summary: string; style: string } | null>
  onReset: () => void
  onBack: () => void
}) {
  const [draft, setDraft] = useState("")
  const [nudge, setNudge] = useState("")
  const [nudged, setNudged] = useState(false)
  const [memoryLang, setMemoryLang] = useState<Lang | null>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const [answerDraft, setAnswerDraft] = useState("")
  const [picked, setPicked] = useState<number[]>([])
  const [recapOpen, setRecapOpen] = useState(false)

  // The panel slides under the frame, swaps its content, then rises back with a
  // soft overshoot. `shown` is the content on screen; the live props are what
  // the flow wants next.
  type PanelView = {
    stage: FlowStage
    direction: Direction | null
    lang: Lang
    reflection: string[]
    question: Question | null
    proposal: Direction | null
    rationale: string
    brief: Brief | null
  }
  const live: PanelView = {
    stage: liveStage,
    direction: liveDirection,
    lang: liveLang,
    reflection: liveReflection,
    question: liveQuestion,
    proposal: liveProposal,
    rationale: liveRationale,
    brief: liveBrief,
  }
  const viewKey = (view: PanelView) =>
    `${view.stage}|${view.question?.prompt ?? ""}|${view.proposal?.id ?? ""}`
  const liveRef = useRef(live)
  liveRef.current = live
  const liveKey = viewKey(live)
  const [shown, setShown] = useState<PanelView>(live)
  const [phase, setPhase] = useState<
    "hidden" | "intro" | "leaving" | "entering" | "idle"
  >("hidden")
  const { stage, direction, lang, reflection, question, proposal, rationale, brief } =
    shown
  const t = ui(lang)
  // While writing, the panel already answers in the language of the story.
  const tm = ui(memoryLang ?? lang)
  const typedPlaceholder = useTypewriter(tm.starters, stage === "memory" && draft.length === 0)
  const prefersReducedMotion = () =>
    window.matchMedia("(prefers-reduced-motion: reduce)").matches

  useEffect(() => {
    if (isLoading || phase !== "hidden") return
    setPhase(prefersReducedMotion() ? "idle" : "intro")
  }, [isLoading, phase])

  useEffect(() => {
    if (viewKey(shown) === liveKey) {
      setPhase((current) => (current === "leaving" ? "idle" : current))
      return
    }
    if (prefersReducedMotion() || phase === "hidden" || phase === "intro") {
      setShown(liveRef.current)
      return
    }
    setPhase("leaving")
    const timer = window.setTimeout(() => {
      setShown(liveRef.current)
      setPhase("entering")
    }, 380)
    return () => window.clearTimeout(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [liveKey])

  const phaseClass =
    phase === "hidden"
      ? " co-creation-hidden"
      : phase === "intro"
        ? " co-creation-rise co-creation-intro"
        : phase === "entering"
          ? " co-creation-rise"
          : phase === "leaving"
            ? " co-creation-sink"
            : ""

  useEffect(() => {
    setPicked([])
    setRecapOpen(false)
  }, [question?.prompt, proposal?.id, stage])

  useEffect(() => {
    if (stage === "invitation") {
      setDraft("")
      setNudge("")
      setNudged(false)
      setMemoryLang(null)
    }
  }, [stage])

  const submitMemory = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const nextMemory = draft.trim()
    if (!nextMemory) {
      setNudge(tm.blank)
      return
    }
    // A story that is only a few words gets one gentle question, never a refusal.
    if (!nudged && isThinStory(nextMemory)) {
      const storyLang = detectLang(nextMemory, lang)
      setMemoryLang(storyLang)
      setNudge(nudgeLine(storyLang, extractEntities(nextMemory)))
      setNudged(true)
      textareaRef.current?.focus()
      return
    }
    setNudge("")
    onMemorySubmit(nextMemory)
  }

  const submitAnswer = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!question || busy) return
    const text = answerDraft.trim()
    if (picked.length === 0 && !text) return
    // Several answers can be combined, plus the person's own words.
    const weights: Record<string, number> = {}
    let tag: Tag = {}
    const addWeights = (next: Partial<AxisScores>) => {
      Object.entries(next).forEach(([axis, value]) => {
        weights[axis] = (weights[axis] ?? 0) + (value ?? 0)
      })
    }
    picked.forEach((index) => {
      const option = question.options[index]
      if (!option) return
      addWeights(option.weights)
      tag = {
        ...tag,
        ...option.tag,
        // Touches add up across picks instead of replacing each other.
        ...(option.tag?.touches
          ? { touches: [...(tag.touches ?? []), ...option.tag.touches] }
          : {}),
        ...(option.tag?.ai ? { ai: [...(tag.ai ?? []), ...option.tag.ai] } : {}),
      }
    })
    if (text) {
      addWeights(scoreText(text))
      tag = { ...tag, ...tagFromText(text) }
    }
    setAnswerDraft("")
    const summary = [...picked.map((i) => question.options[i]?.label).filter(Boolean), text]
      .filter(Boolean)
      .join("; ")
    onAnswer(weights as Partial<AxisScores>, tag, summary)
  }

  return (
    <aside
      className={`co-creation-panel co-creation-${stage}${phaseClass}`}
      style={{ backgroundImage: `url(${paperTexture})` }}
      aria-label="Atelier Co-Creation"
      inert={phase === "hidden" || phase === "intro" || phase === "leaving"}
      onPointerDown={(event) => event.stopPropagation()}
      onAnimationEnd={(event) => {
        if (
          event.target === event.currentTarget &&
          (phase === "intro" || phase === "entering")
        )
          setPhase("idle")
      }}
    >
      <div className="co-creation-content" aria-live="polite">
        {stage !== "invitation" && (
          <div className="chat-header">
            {stage === "followup" || stage === "direction" ? (
              <button
                className="chat-icon"
                type="button"
                onClick={onBack}
                aria-label={t.back}
              >
                <svg viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M20 12H4M10 6l-6 6 6 6" />
                </svg>
              </button>
            ) : (
              <span />
            )}
            <button
              className="chat-icon"
              type="button"
              onClick={onReset}
              aria-label={t.startOver}
            >
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M5 5l14 14M19 5L5 19" />
              </svg>
            </button>
          </div>
        )}
        {stage === "invitation" && (
          <div className="flow-centered" data-node-id="89:37">
            <p className="flow-title">
              What is a memory you would
              <br />
              like to keep?
            </p>
            <button
              className="invitation-arrow"
              type="button"
              onClick={onBegin}
              aria-label="Begin Co-Creation"
            >
              <img src={invitationArrow} alt="" />
            </button>
          </div>
        )}

        {stage === "memory" && (
          <form
            className="memory-form story-form"
            onSubmit={submitMemory}
            data-node-id="89:43"
          >
            <label className="flow-title" htmlFor="atelier-memory">
              {tm.memoryTitle}
            </label>
            <p
              id="story-hint"
              className={`story-hint${nudge ? " story-nudge" : ""}`}
              role={nudge ? "status" : undefined}
              key={nudge || "hint"}
            >
              {nudge || tm.memoryHint}
            </p>
            <div className="story-field">
              <textarea
                id="atelier-memory"
                ref={textareaRef}
                rows={3}
                value={draft}
                onChange={(event) => setDraft(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && !event.shiftKey) {
                    event.preventDefault()
                    event.currentTarget.form?.requestSubmit()
                  }
                }}
                maxLength={storyMaxLength}
                placeholder={typedPlaceholder}
                autoFocus
                aria-describedby="story-hint"
              />
            </div>
            <p className="story-count" aria-hidden="true">
                {draft.length} / {storyMaxLength}
              </p>
            <div className={`story-spark${draft.length > 0 ? " story-spark-used" : ""}`}>
              <p className="story-spark-label">{tm.sampleLabel}</p>
              <div className="story-samples">
                {sampleStories(memoryLang ?? lang).map((sample) => (
                  <button
                    key={sample.title}
                    type="button"
                    onClick={() => {
                      setDraft(sample.text)
                      setNudge("")
                      textareaRef.current?.focus()
                    }}
                  >
                    <span>{sample.title}</span>
                    <svg viewBox="0 0 24 24" aria-hidden="true">
                      <path d="M17 17L7 7M7 15V7h8" />
                    </svg>
                  </button>
                ))}
              </div>
            </div>
            <button className="story-submit" type="submit">
              {tm.memorySubmit}
            </button>
          </form>
        )}

        {stage === "thinking" && (
          <div className="flow-centered loading-step" role="status">
            <LoadingStar />
            <p className="flow-title">
              {lang === "it" ? "Leggo tra le righe..." : "Reading between the lines..."}
            </p>
          </div>
        )}

        {stage === "reflection" && (
          <div className="flow-centered reflection-lines" data-node-id="89:52">
            {reflection.map((line, index) => (
              <p
                key={line}
                className="flow-title reflection-copy reflection-line"
                style={{ animationDelay: `${0.5 + index * 1.1}s` }}
              >
                {line}
              </p>
            ))}
          </div>
        )}

        {stage === "followup" && question && (
          <form
            className="direction-step followup-step"
            onSubmit={submitAnswer}
            key={question.prompt}
          >
            <p className="flow-title">{question.prompt}</p>
            <p className="followup-hint">{t.followupHint}</p>
            <div className="direction-options" role="group" aria-label={question.prompt}>
              {question.options.map((option, index) => (
                <button
                  key={option.label}
                  type="button"
                  aria-pressed={picked.includes(index)}
                  className={picked.includes(index) ? "is-picked" : undefined}
                  onClick={() =>
                    setPicked((current) =>
                      current.includes(index)
                        ? current.filter((i) => i !== index)
                        : [...current, index],
                    )
                  }
                >
                  {String.fromCharCode(65 + index)}) {option.label}
                </button>
              ))}
            </div>
            <input
              className="followup-input"
              value={answerDraft}
              onChange={(event) => setAnswerDraft(event.target.value)}
              maxLength={120}
              placeholder={t.followupPlaceholder}
              aria-label={t.followupAria}
            />
            <button
              className="story-submit"
              type="submit"
              disabled={busy || (picked.length === 0 && !answerDraft.trim())}
            >
              {busy ? "..." : t.next}
            </button>
          </form>
        )}

        {stage === "direction" && proposal && (
          <div
            className={`direction-step recap-step${recapOpen ? " is-open" : ""}`}
            data-node-id="939:624"
          >
            <div className="recap-head">
              <p className="flow-title">{t.hear(directionLabel(lang, proposal.id))}</p>
              <p className="recap-sub">{rationale}</p>
            </div>
            {brief && (
              <dl className="recap-rows">
                {briefRows(lang, brief).map((row, index) => (
                  <div key={row.label} className={index >= 2 ? "recap-extra" : undefined}>
                    <dt>{row.label}</dt>
                    <dd>{row.text}</dd>
                  </div>
                ))}
              </dl>
            )}
            <button
              className="recap-more"
              type="button"
              aria-expanded={recapOpen}
              onClick={() => setRecapOpen((open) => !open)}
            >
              {recapOpen
                ? lang === "it" ? "Meno dettagli" : "Less details"
                : lang === "it" ? "Tutti i dettagli" : "All details"}
            </button>
            <div className="recap-actions">
              <button
                className="recap-confirm"
                type="button"
                onClick={() => proposal && onDirectionSelect(proposal)}
                disabled={isFiltering || busy}
              >
                {t.confirm}
              </button>
              <button
                className="recap-another"
                type="button"
                onClick={onShowAnother}
                disabled={isFiltering || busy}
              >
                {t.another}
              </button>
            </div>
          </div>
        )}

        {stage === "loading" && (
          <div className="flow-centered loading-step" role="status">
            <LoadingStar />
            <p className="flow-title">{t.loadingTitle}</p>
          </div>
        )}

        {stage === "pinning" && (
          <div className="pinning-step" data-node-id="89:60">
            <p className="flow-title">
              {t.pinTitle[0]}
              <br />
              {t.pinTitle[1]}
            </p>
            <div className="pinning-actions">
              <button
                className="ink-action done-action"
                type="button"
                onClick={onDone}
                disabled={pinnedCards.length === 0}
                aria-label={
                  pinnedCards.length === 0
                    ? "Pin at least one reference before continuing"
                    : `Create Story Card with ${pinnedCards.length} pinned reference${
                        pinnedCards.length === 1 ? "" : "s"
                      }`
                }
              >
                <img src={doneStamp} alt="" />
                <span>{t.done}</span>
              </button>
              <button
                className="ink-action reset-action"
                type="button"
                onClick={onReset}
              >
                <img src={resetOval} alt="" />
                <span>{t.reset}</span>
              </button>
            </div>
            <span className="sr-only" aria-live="polite">
              {pinnedCards.length} of 3 references pinned
            </span>
          </div>
        )}

        {stage === "story" && direction && (
          <FinalStep
            lang={lang}
            brief={brief}
            memory={memory}
            pinnedCards={pinnedCards}
            product={product}
            onWriteSheet={onWriteSheet}
          />
        )}
      </div>
    </aside>
  )
}

function AmbientPlayer() {
  const audioRef = useRef<HTMLAudioElement>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [hasAudioError, setHasAudioError] = useState(false)

  const togglePlayback = async () => {
    const audio = audioRef.current
    if (!audio || isLoading) return

    if (isPlaying) {
      audio.pause()
      return
    }

    setIsLoading(true)
    setHasAudioError(false)
    try {
      await audio.play()
    } catch {
      setHasAudioError(true)
      setIsPlaying(false)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <section
      className="ambient-player"
      aria-label="Atelier ambience player"
      onPointerDown={(event) => event.stopPropagation()}
    >
      <audio
        ref={audioRef}
        src={ambientAudio}
        preload="none"
        loop
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onEnded={() => setIsPlaying(false)}
        onError={() => {
          setHasAudioError(true)
          setIsPlaying(false)
          setIsLoading(false)
        }}
      />
      <button
        className="ambient-play"
        type="button"
        onClick={togglePlayback}
        disabled={isLoading}
        aria-label={
          isPlaying ? "Pause atelier ambience" : "Play atelier ambience"
        }
      >
        {isPlaying ? (
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <path d="M7 5h4v14H7zM14 5h4v14h-4z" />
          </svg>
        ) : (
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <path d="m8 5 11 7-11 7z" />
          </svg>
        )}
      </button>
      <span className="sr-only" aria-live="polite">
        {hasAudioError ? "Ambient audio file is not available yet." : ""}
      </span>
    </section>
  )
}

// Where each card is blown to: different edges, a little spin, staggered starts.
const windGusts = [
  { x: "-130vw", y: "-18vh", r: "-28deg", delay: "0ms" },
  { x: "36vw", y: "-130vh", r: "22deg", delay: "140ms" },
  { x: "130vw", y: "14vh", r: "34deg", delay: "60ms" },
  { x: "-24vw", y: "130vh", r: "-18deg", delay: "220ms" },
  { x: "120vw", y: "-90vh", r: "26deg", delay: "110ms" },
  { x: "-120vw", y: "90vh", r: "-36deg", delay: "180ms" },
  { x: "-40vw", y: "-130vh", r: "16deg", delay: "30ms" },
  { x: "70vw", y: "130vh", r: "-24deg", delay: "260ms" },
]

const atelierCities = ["Milan", "Venice", "Seoul", "San Francisco", "Tokyo"]

function randomArchiveInfo() {
  const city = atelierCities[Math.floor(Math.random() * atelierCities.length)]
  const start = new Date(2021, 0, 1).getTime()
  const end = Math.min(new Date(2026, 11, 31).getTime(), Date.now())
  const made = new Date(start + Math.random() * (end - start))
  const two = (n: number) => String(n).padStart(2, "0")
  return {
    city,
    date: `${two(made.getDate())}.${two(made.getMonth() + 1)}.${made.getFullYear()}`,
  }
}

export default function App() {
  const [isGalleryLoading, setIsGalleryLoading] = useState(true)
  const [positions, setPositions] = useState<Record<number, Point>>({})
  const [topCard, setTopCard] = useState(0)
  const [selectedProductId, setSelectedProductId] = useState(defaultProductId)
  const [swapCount, setSwapCount] = useState(0)
  const [isSwapping, setIsSwapping] = useState(false)
  const [visibleCardIds, setVisibleCardIds] = useState<number[]>(() =>
    cardIdsFor(defaultCategory),
  )
  const [exitingCardIds, setExitingCardIds] = useState<number[]>([])
  const [blownCardIds, setBlownCardIds] = useState<number[]>([])
  const matchedIdsRef = useRef<number[]>([])
  // Adaptive chat (Claude via the artifact "sample" capability); null = not decided yet.
  const [aiMode, setAiMode] = useState<boolean | null>(null)
  const [aiReflection, setAiReflection] = useState<string[]>([])
  const [aiQuestions, setAiQuestions] = useState<AiQuestion[]>([])
  const [aiResult, setAiResult] = useState<{
    axis: Axis
    tags: AiTag[]
    rationale: string
    brief: AiBrief
    visibility: "hidden" | "small" | "bold"
  } | null>(null)
  const [aiBusy, setAiBusy] = useState(false)
  const [refineQ, setRefineQ] = useState<Question | null>(null)
  const aiReadingRef = useRef("")
  const aiLogRef = useRef<(AiLogEntry & { tags: AiTag[] })[]>([])
  const aiAbortRef = useRef<AbortController | null>(null)
  const [pinnedCardIds, setPinnedCardIds] = useState<number[]>([])
  const [flowStage, setFlowStage] = useState<FlowStage>("invitation")
  const [memory, setMemory] = useState("")
  const [scores, setScores] = useState<AxisScores>(emptyScores)
  const [followupStep, setFollowupStep] = useState(0)
  const historyRef = useRef<{ scores: AxisScores; answers: Tag }[]>([])
  const [proposalIndex, setProposalIndex] = useState(0)
  const [lang, setLang] = useState<Lang>("en")
  const [entities, setEntities] = useState<Entities>({})
  const [answers, setAnswers] = useState<Tag>({})
  const [selectedDirection, setSelectedDirection] = useState<Direction | null>(
    null,
  )
  const [isFiltering, setIsFiltering] = useState(false)
  const [fullScreenCardId, setFullScreenCardId] = useState<number | null>(null)
  const archiveInfoRef = useRef<Record<number, { city: string; date: string }>>({})
  const dragRef = useRef<{
    id: number
    pointerId: number
    origin: Point
    start: Point
    last: Point
    lastTime: number
    velocity: Point
    moved: boolean
  } | null>(null)
  const suppressClickRef = useRef<number | null>(null)
  const positionsRef = useRef(positions)
  const animationRef = useRef<Record<number, number>>({})
  const reflectionTimerRef = useRef<number | null>(null)
  const filterTimerRef = useRef<number | null>(null)
  const swapTimerRef = useRef<number | null>(null)

  useEffect(() => {
    void getSample()
  }, [])

  useEffect(() => {
    positionsRef.current = positions
  }, [positions])

  useEffect(() => {
    let cancelled = false
    const sources = [
      woodTexture,
      fabricRolls,
      pencilTray,
      ...cards
        .filter((card) => cardIdsFor(defaultCategory).includes(card.id))
        .map((card) => card.image),
    ]

    Promise.all(
      sources.map(
        (source) =>
          new Promise<void>((resolve) => {
            const image = new Image()
            image.onload = () => resolve()
            image.onerror = () => resolve()
            image.src = source
          }),
      ),
    ).then(() => {
      if (cancelled) return
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          if (!cancelled) setIsGalleryLoading(false)
        })
      })
    })

    return () => {
      cancelled = true
    }
  }, [])

  useEffect(() => {
    cards.forEach((card) => {
      const image = new Image()
      image.src = card.image
    })
  }, [])

  useEffect(() => {
    return () => {
      if (swapTimerRef.current !== null)
        window.clearTimeout(swapTimerRef.current)
      Object.values(animationRef.current).forEach(cancelAnimationFrame)
      if (reflectionTimerRef.current !== null)
        window.clearTimeout(reflectionTimerRef.current)
      if (filterTimerRef.current !== null)
        window.clearTimeout(filterTimerRef.current)
    }
  }, [])

  useEffect(() => {
    if (flowStage !== "reflection") return
    reflectionTimerRef.current = window.setTimeout(() => {
      setFlowStage("followup")
    }, 5200)
    return () => {
      if (reflectionTimerRef.current !== null)
        window.clearTimeout(reflectionTimerRef.current)
    }
  }, [flowStage])

  useEffect(() => {
    if (fullScreenCardId === null) return

    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setFullScreenCardId(null)
    }
    window.addEventListener("keydown", closeOnEscape)
    return () => window.removeEventListener("keydown", closeOnEscape)
  }, [fullScreenCardId])

  const moveCard = (id: number, point: Point) => {
    positionsRef.current = { ...positionsRef.current, [id]: point }
    setPositions(positionsRef.current)
  }

  const beginDrag = (event: React.PointerEvent<HTMLElement>, id: number) => {
    cancelAnimationFrame(animationRef.current[id])
    event.currentTarget.setPointerCapture(event.pointerId)
    const origin = positionsRef.current[id] ?? { x: 0, y: 0 }
    dragRef.current = {
      id,
      pointerId: event.pointerId,
      origin,
      start: { x: event.clientX, y: event.clientY },
      last: { x: event.clientX, y: event.clientY },
      lastTime: performance.now(),
      velocity: { x: 0, y: 0 },
      moved: false,
    }
    setTopCard(id)
  }

  const dragCard = (event: React.PointerEvent<HTMLElement>) => {
    const drag = dragRef.current
    if (!drag || drag.pointerId !== event.pointerId) return

    const now = performance.now()
    const elapsed = Math.max(now - drag.lastTime, 8)
    if (
      Math.abs(event.clientX - drag.start.x) +
        Math.abs(event.clientY - drag.start.y) >
      4
    ) {
      drag.moved = true
    }
    drag.velocity = {
      x: ((event.clientX - drag.last.x) / elapsed) * 16,
      y: ((event.clientY - drag.last.y) / elapsed) * 16,
    }
    drag.last = { x: event.clientX, y: event.clientY }
    drag.lastTime = now
    moveCard(drag.id, {
      x: drag.origin.x + event.clientX - drag.start.x,
      y: drag.origin.y + event.clientY - drag.start.y,
    })
  }

  const endDrag = (event: React.PointerEvent<HTMLElement>) => {
    const drag = dragRef.current
    if (!drag || drag.pointerId !== event.pointerId) return
    dragRef.current = null
    if (drag.moved) {
      suppressClickRef.current = drag.id
      window.setTimeout(() => {
        if (suppressClickRef.current === drag.id)
          suppressClickRef.current = null
      }, 0)
    }

    let point = positionsRef.current[drag.id] ?? { x: 0, y: 0 }
    let velocity = drag.velocity
    const card = event.currentTarget

    const coast = () => {
      velocity = { x: velocity.x * 0.92, y: velocity.y * 0.92 }
      point = { x: point.x + velocity.x, y: point.y + velocity.y }

      const rect = card.getBoundingClientRect()
      const margin = 56
      if (rect.right < margin && velocity.x < 0) velocity.x *= -0.55
      if (rect.left > window.innerWidth - margin && velocity.x > 0)
        velocity.x *= -0.55
      if (rect.bottom < margin && velocity.y < 0) velocity.y *= -0.55
      if (rect.top > window.innerHeight - margin && velocity.y > 0)
        velocity.y *= -0.55

      moveCard(drag.id, point)
      if (Math.abs(velocity.x) + Math.abs(velocity.y) > 0.12) {
        animationRef.current[drag.id] = requestAnimationFrame(coast)
      }
    }
    animationRef.current[drag.id] = requestAnimationFrame(coast)
  }

  const activateCard = (id: number) => {
    if (suppressClickRef.current === id) {
      suppressClickRef.current = null
      return
    }

    if (flowStage === "pinning") {
      setPinnedCardIds((current) =>
        current.includes(id)
          ? current.filter((cardId) => cardId !== id)
          : [...current, id],
      )
      return
    }

    setFullScreenCardId(id)
  }

  const selectedProduct =
    products.find((product) => product.id === selectedProductId) ?? products[0]

  const changeProduct = (productId: string) => {
    const product = products.find((item) => item.id === productId)
    if (!product || product.id === selectedProductId || isFiltering) return
    setSelectedProductId(product.id)
    // Same category: the references stay, only the drawer changes.
    if (product.category === selectedProduct.category && !isSwapping) return

    const narrowing =
      flowStage === "loading" || flowStage === "pinning" || flowStage === "story"
        ? selectedDirection
        : null
    const nextIds = cards
      .filter(
        (card) =>
          card.category === product.category &&
          (!narrowing || card.directions.includes(narrowing.id)),
      )
      .map((card) => card.id)

    if (swapTimerRef.current !== null) window.clearTimeout(swapTimerRef.current)
    setIsSwapping(true)
    setExitingCardIds(visibleCardIds)
    swapTimerRef.current = window.setTimeout(() => {
      Object.values(animationRef.current).forEach(cancelAnimationFrame)
      animationRef.current = {}
      positionsRef.current = {}
      setPositions({})
      setTopCard(0)
      setVisibleCardIds(nextIds)
      setExitingCardIds([])
      setPinnedCardIds([])
      if (flowStage === "story") setFlowStage("pinning")
      setSwapCount((count) => count + 1)
      setIsSwapping(false)
    }, 400)
  }

  useEffect(() => {
    if (flowStage !== "loading") return
    const timer = window.setTimeout(() => {
      const matchedIds = matchedIdsRef.current
      if (matchedIds.length > 0) {
        const nextPositions = { ...positionsRef.current }
        matchedIds.forEach((id) => {
          cancelAnimationFrame(animationRef.current[id])
          delete nextPositions[id]
        })
        positionsRef.current = nextPositions
        setPositions(nextPositions)
        setVisibleCardIds(matchedIds)
      }
      setBlownCardIds([])
      setPinnedCardIds([])
      setFlowStage("pinning")
    }, 3100)
    return () => window.clearTimeout(timer)
  }, [flowStage])

  const selectDirection = (direction: Direction) => {
    if (isSwapping) return
    const inCategory = cards.filter((card) => card.category === selectedProduct.category)
    const byDirection = inCategory.filter((card) => card.directions.includes(direction.id))
    let matchedIds = byDirection.map((card) => card.id)
    if (aiMode && aiResult && proposalIndex === 0) {
      // Keep only works that share the techniques, motifs and mood the chat found.
      const overlap = (card: Card) => card.tags.filter((tag) => aiResult.tags.includes(tag as AiTag)).length
      let picked = inCategory.filter((card) => overlap(card) >= 2)
      if (picked.length < 3) picked = inCategory.filter((card) => overlap(card) >= 1)
      if (picked.length < 3)
        picked = [...picked, ...byDirection.filter((card) => !picked.includes(card))]
      matchedIds = picked.map((card) => card.id)
    }
    if (matchedIds.length === 0) return

    setSelectedDirection(direction)
    matchedIdsRef.current = matchedIds
    setBlownCardIds(visibleCardIds.filter((id) => !matchedIds.includes(id)))
    setFlowStage("loading")
  }

  // One step back: the story box, the previous question, or the last question
  // from the direction screen. Answers are restored from a small history.
  const goBack = () => {
    if (isFiltering) return
    if (refineQ) {
      setRefineQ(null)
      setFlowStage("direction")
      return
    }
    if (flowStage === "memory") {
      setFlowStage("invitation")
      return
    }
    if (flowStage === "followup" && followupStep === 0) {
      historyRef.current = []
      setFlowStage("memory")
      return
    }
    if (flowStage === "followup" || flowStage === "direction") {
      const previous = historyRef.current.pop()
      if (previous) {
        setScores(previous.scores)
        setAnswers(previous.answers)
      }
      setProposalIndex(0)
      if (flowStage === "direction") setFlowStage("followup")
      else setFollowupStep(followupStep - 1)
    }
  }

  const resetExperience = () => {
    historyRef.current = []
    aiAbortRef.current?.abort()
    aiLogRef.current = []
    setAiBusy(false)
    setRefineQ(null)
    setAiMode(null)
    setAiReflection([])
    setAiQuestions([])
    setAiResult(null)
    if (reflectionTimerRef.current !== null)
      window.clearTimeout(reflectionTimerRef.current)
    if (filterTimerRef.current !== null)
      window.clearTimeout(filterTimerRef.current)
    Object.values(animationRef.current).forEach(cancelAnimationFrame)
    animationRef.current = {}
    positionsRef.current = {}
    setPositions({})
    setTopCard(0)
    if (swapTimerRef.current !== null) window.clearTimeout(swapTimerRef.current)
    setIsSwapping(false)
    setVisibleCardIds(cardIdsFor(selectedProduct.category))
    setExitingCardIds([])
    setBlownCardIds([])
    setPinnedCardIds([])
    setFlowStage("invitation")
    setMemory("")
    setScores(emptyScores)
    setLang("en")
    setEntities({})
    setAnswers({})
    setFollowupStep(0)
    setProposalIndex(0)
    setSelectedDirection(null)
    setIsFiltering(false)
    setFullScreenCardId(null)
  }

  const visibleCards = cards.filter((card) => visibleCardIds.includes(card.id))
  const pinnedCards = cards.filter((card) => pinnedCardIds.includes(card.id))
  const fullScreenCard = cards.find((card) => card.id === fullScreenCardId)
  if (fullScreenCard && !archiveInfoRef.current[fullScreenCard.id])
    archiveInfoRef.current[fullScreenCard.id] = randomArchiveInfo()
  const archiveInfo = fullScreenCard
    ? archiveInfoRef.current[fullScreenCard.id]
    : null
  const isFilteredLayout =
    flowStage === "pinning" ||
    flowStage === "story" ||
    isFiltering

  const ranked = rankAxes(scores)
  const proposedAxis = ranked[proposalIndex % ranked.length]
  const proposedDirection = directions.find((d) => d.id === proposedAxis) ?? null
  const activeAxis: Axis | null =
    flowStage === "loading" || flowStage === "pinning" || flowStage === "story"
      ? (selectedDirection?.id ?? null)
      : flowStage === "direction"
        ? proposedAxis
        : flowStage === "followup" && hasSignal(scores)
          ? ranked[0]
          : null
  const activeDirection = directions.find((d) => d.id === activeAxis)
  const aiQuestion = aiMode ? aiQuestions[followupStep] : undefined
  const question: Question | null =
    flowStage === "followup"
      ? refineQ
        ? refineQ
        : aiMode
        ? aiQuestion
          ? toQuestion(aiQuestion)
          : null
        : getQuestion(followupStep, {
          lang,
          category: selectedProduct.category,
          memory,
          entities,
          scores,
          answers,
        })
      : null
  const aiActive = aiMode === true && aiResult !== null && proposalIndex === 0
  const baseBrief: Brief | null = activeAxis
    ? buildBrief({
        lang,
        category: selectedProduct.category,
        axis: activeAxis,
        entities,
        answers: aiActive && aiResult ? { ...answers, visibility: aiResult.visibility } : answers,
        memory,
      })
    : null
  const brief: Brief | null =
    baseBrief && aiActive && aiResult
      ? {
          ...baseBrief,
          ...Object.fromEntries(
            Object.entries(aiResult.brief).filter(([, value]) => value),
          ),
        }
      : baseBrief
  const answerAdaptive = async (tag: Tag | undefined, summary: string) => {
    const step = followupStep
    const asked = aiQuestions[step]
    if (!asked) return
    const ctl = aiAbortRef.current ?? new AbortController()
    aiAbortRef.current = ctl
    historyRef.current.push({ scores, answers })
    aiLogRef.current = [
      ...aiLogRef.current.slice(0, step),
      { prompt: asked.prompt, answer: summary || "(no answer)", tags: (tag?.ai ?? []) as AiTag[] },
    ]
    setProposalIndex(0)
    const story = memory
    const log = aiLogRef.current.map(({ prompt, answer }) => ({ prompt, answer }))
    if (step === 0) {
      setAiBusy(true)
      const next = await followUps(story, aiReadingRef.current, log, selectedProduct.category, catalogue, ctl.signal)
      if (ctl.signal.aborted) return
      setAiBusy(false)
      if (next) setAiQuestions([asked, ...next])
      else setAiMode(false)
      setFollowupStep(1)
      setFlowStage("followup")
    } else if (step < 2) {
      setFollowupStep(step + 1)
    } else {
      setAiBusy(true)
      const tags = aiLogRef.current.flatMap((entry) => entry.tags)
      const res = await conclude(story, aiReadingRef.current, log, tags, selectedProduct.category, catalogue, ctl.signal)
      if (ctl.signal.aborted) return
      setAiBusy(false)
      if (res) {
        setAiResult(res)
        setScores({ ...emptyScores, [res.axis]: 5 })
      } else {
        setAiMode(false)
      }
      setFlowStage("direction")
    }
  }

  const startAdaptive = async (story: string) => {
    aiAbortRef.current?.abort()
    const ctl = new AbortController()
    aiAbortRef.current = ctl
    aiLogRef.current = []
    setAiResult(null)
    setAiQuestions([])
    setAiReflection([])
    const sample = await getSample()
    if (ctl.signal.aborted) return
    if (!sample) {
      setAiMode(false)
      setFlowStage("reflection")
      return
    }
    setAiMode(true)
    setFlowStage("thinking")
    const res = await analyzeStory(story, selectedProduct.category, catalogue, ctl.signal)
    if (ctl.signal.aborted) return
    if (res) {
      aiReadingRef.current = res.reading
      setAiReflection(res.reflection)
      setAiQuestions([res.question])
    } else {
      setAiMode(false)
    }
    setFlowStage("reflection")
  }

  const startRefine = async () => {
    if (isFiltering || aiBusy || !activeAxis) return
    const ctl = aiAbortRef.current ?? new AbortController()
    aiAbortRef.current = ctl
    let asked: Question = refineQuestion(lang, activeAxis)
    if (aiMode && aiResult && aiActive) {
      setAiBusy(true)
      const shown = brief ? briefRows(lang, brief).map((row) => row.text).join("; ") : ""
      const q = await refineAsk(
        memory,
        aiReadingRef.current,
        aiLogRef.current.map(({ prompt, answer }) => ({ prompt, answer })),
        { axis: activeAxis, tags: aiResult.tags, summary: shown },
        selectedProduct.category,
        catalogue,
        ctl.signal,
      )
      setAiBusy(false)
      if (ctl.signal.aborted) return
      if (q) asked = toQuestion(q)
    }
    setRefineQ(asked)
    setFlowStage("followup")
  }

  const answerRefine = async (weights: Partial<AxisScores>, tag?: Tag, summary = "") => {
    const asked = refineQ
    if (!asked) return
    setRefineQ(null)
    if (aiMode && aiResult) {
      const ctl = aiAbortRef.current ?? new AbortController()
      aiAbortRef.current = ctl
      aiLogRef.current = [
        ...aiLogRef.current,
        { prompt: asked.prompt, answer: summary || "(no answer)", tags: (tag?.ai ?? []) as AiTag[] },
      ]
      setFlowStage("direction")
      setAiBusy(true)
      const log = aiLogRef.current.map(({ prompt, answer }) => ({ prompt, answer }))
      const res = await conclude(
        memory,
        aiReadingRef.current,
        log,
        aiLogRef.current.flatMap((entry) => entry.tags),
        selectedProduct.category,
        catalogue,
        ctl.signal,
        { axis: aiResult.axis, tags: aiResult.tags },
      )
      setAiBusy(false)
      if (ctl.signal.aborted) return
      if (res) {
        setAiResult(res)
        setScores({ ...emptyScores, [res.axis]: 5 })
        setProposalIndex(0)
      } else {
        setProposalIndex((index) => index + 1)
      }
      return
    }
    const next = addScores(emptyScores, weights)
    if (hasSignal(next)) {
      setScores(next)
      setProposalIndex(0)
    } else setProposalIndex((index) => index + 1)
    setFlowStage("direction")
  }

  const answerFollowup = (weights: Partial<AxisScores>, tag?: Tag, summary = "") => {
    if (refineQ) {
      void answerRefine(weights, tag, summary)
      return
    }
    if (aiMode) {
      void answerAdaptive(tag, summary)
      return
    }
    historyRef.current.push({ scores, answers })
    setScores((current) => addScores(current, weights))
    if (tag) setAnswers((current) => ({ ...current, ...tag }))
    setProposalIndex(0)
    if (followupStep >= totalQuestions - 1) setFlowStage("direction")
    else setFollowupStep(followupStep + 1)
  }

  return (
    <main
      className={`gallery${isGalleryLoading ? " gallery-loading" : ""}${
        flowStage === "pinning" ? " gallery-pinning" : ""
      }`}
      aria-label="Interactive floating photo gallery"
      style={{ backgroundImage: `url(${woodTexture})` }}
    >
      <div className="fabric-rolls" aria-hidden="true">
        <img src={fabricRolls} alt="" draggable="false" />
      </div>
      <img
        className="pencil-tray"
        src={pencilTray}
        alt=""
        aria-hidden="true"
        draggable="false"
      />
      {visibleCards.map((card, index) => {
        const position = positions[card.id] ?? { x: 0, y: 0 }
        const entrance = entranceDirections[index % entranceDirections.length]
        const filteredLayout = filteredLayouts[index % filteredLayouts.length]
        const isPinned = pinnedCardIds.includes(card.id)
        const isExiting = exitingCardIds.includes(card.id)
        const isBlown = blownCardIds.includes(card.id)
        const wind = windGusts[index % windGusts.length]
        const cardLeft = isFilteredLayout ? filteredLayout.left : card.left
        const cardTop = isFilteredLayout ? filteredLayout.top : card.top
        const cardRotation = isFilteredLayout
          ? filteredLayout.rotation
          : card.rotation

        return (
          <article
            className={`card-anchor${isFilteredLayout ? " card-filtered" : ""}${
              isExiting ? " card-exiting" : ""
            }${isPinned ? " card-pinned" : ""}${isBlown ? " card-blown" : ""}`}
            key={card.id}
            onPointerDown={(event) => beginDrag(event, card.id)}
            onPointerMove={dragCard}
            onPointerUp={endDrag}
            onPointerCancel={endDrag}
            onClick={() => activateCard(card.id)}
            onKeyDown={(event) => {
              if (event.key === "Enter" || event.key === " ") {
                event.preventDefault()
                activateCard(card.id)
              }
            }}
            role="button"
            tabIndex={0}
            aria-pressed={flowStage === "pinning" ? isPinned : undefined}
            aria-label={
              flowStage === "pinning"
                ? `${isPinned ? "Unpin" : "Pin"} ${card.alt}`
                : `Open ${card.alt} full screen`
            }
            style={{
              left: `${cardLeft}%`,
              top: `${cardTop}%`,
              zIndex: isPinned ? 48 : topCard === card.id ? 50 : index + 2,
              transform: `translate3d(${position.x}px, ${position.y}px, 0) scale(${card.scale ?? 1})`,
              "--blow-x": wind.x,
              "--blow-y": wind.y,
              "--blow-r": wind.r,
              "--blow-delay": wind.delay,
            } as React.CSSProperties}
          >
            {isPinned && <span className="artisan-pin" aria-hidden="true" />}
            <div
              className="card-entrance"
              style={
                {
                  "--entry-x": entrance.x,
                  "--entry-y": entrance.y,
                  "--entry-delay":
                    swapCount > 0
                      ? `${index * 160}ms`
                      : `${400 + index * 400}ms`,
                } as React.CSSProperties
              }
            >
              <div
                className="wind"
                style={
                  {
                    "--rotation": `${cardRotation}deg`,
                    "--delay": `${card.delay}s`,
                    "--duration": `${card.duration}s`,
                  } as React.CSSProperties
                }
              >
                <PolaroidFrame
                  image={card.image}
                  alt={card.alt}
                  personalization={card.personalization}
                />
              </div>
            </div>
          </article>
        )
      })}
      <div className="sunlight-streaks" aria-hidden="true">
        <span className="sunlight-left" />
        <span className="sunlight-right" />
      </div>
      <div className="warm-color-burn" aria-hidden="true" />
      <img className="ambient-vignette" src={vignette} alt="" />
      <div className="light-particles" aria-hidden="true">
        {lightParticles.map((particle, index) => (
          <span
            key={index}
            style={
              {
                "--particle-left": `${particle.left}%`,
                "--particle-top": `${particle.top}%`,
                "--particle-size": `${particle.size}px`,
                "--particle-delay": `${particle.delay}s`,
                "--particle-duration": `${particle.duration}s`,
                "--particle-drift": `${particle.drift}px`,
              } as React.CSSProperties
            }
          />
        ))}
      </div>
      <img
        className="golden-light-overlay"
        src={goldenLightOverlay}
        alt=""
        aria-hidden="true"
        draggable="false"
      />
      <div className="corner-vignette" aria-hidden="true" />
      <div className="edge-blur" aria-hidden="true" />
      <div className="grain-filter" aria-hidden="true" />
      <div className="top-bar" aria-hidden="true" />
      <AmbientPlayer />
      <ProductDrawer
        products={products}
        selectedId={selectedProductId}
        onSelect={changeProduct}
      />
      {flowStage === "story" && <div className="final-backdrop" aria-hidden="true" />}
      <CoCreationPanel
        isLoading={isGalleryLoading}
        stage={flowStage}
        memory={memory}
        direction={selectedDirection}
        pinnedCards={pinnedCards}
        isFiltering={isFiltering}
        onBegin={() => setFlowStage("memory")}
        onMemorySubmit={(nextMemory) => {
          setMemory(nextMemory)
          setLang(detectLang(nextMemory, "en"))
          setEntities(extractEntities(nextMemory))
          historyRef.current = []
          setAnswers({})
          setScores(scoreText(nextMemory))
          setFollowupStep(0)
          setProposalIndex(0)
          void startAdaptive(nextMemory)
        }}
        lang={lang}
        reflection={
          aiMode && aiReflection.length
            ? aiReflection
            : reflectionLines(lang, memory, entities, scores)
        }
        question={question}
        proposal={proposedDirection}
        brief={brief}
        rationale={
          aiActive && aiResult
            ? aiResult.rationale
            : activeAxis
            ? buildRationale(lang, activeAxis, memory, proposalIndex > 0)
            : ""
        }
        onAnswer={answerFollowup}
        onShowAnother={() => void startRefine()}
        busy={aiBusy}
        onDirectionSelect={selectDirection}
        product={selectedProduct}
        onDone={() => setFlowStage("story")}
        onWriteSheet={async (works) => {
          if (!aiMode || !brief) return null
          return writeSheet(
            memory,
            aiReadingRef.current,
            aiResult?.brief ?? {},
            works,
            selectedProduct.category,
            aiAbortRef.current?.signal,
          )
        }}
        onReset={resetExperience}
        onBack={goBack}
      />
      {fullScreenCard && (
        <div
          className="fullscreen-view"
          role="dialog"
          aria-modal="true"
          aria-label={`${fullScreenCard.alt} full-screen view`}
          onPointerDown={() => setFullScreenCardId(null)}
        >
          <button
            className="fullscreen-close"
            type="button"
            onClick={() => setFullScreenCardId(null)}
            aria-label="Close full-screen view"
          >
            <img src={closeIcon} alt="" />
          </button>
          <div
            className="fullscreen-card"
            onPointerDown={(event) => event.stopPropagation()}
          >
            <PolaroidFrame
              image={fullScreenCard.image}
              alt={fullScreenCard.alt}
              personalization={fullScreenCard.personalization}
            />
          </div>
          {archiveInfo && (
            <div
              className="fullscreen-info"
              onPointerDown={(event) => event.stopPropagation()}
            >
              <p className="fullscreen-info-label">Archive info:</p>
              <div className="fullscreen-info-rule" aria-hidden="true" />
              <p className="fullscreen-info-place">
                Dream Maker, {archiveInfo.city}
              </p>
              <p className="fullscreen-info-date">{archiveInfo.date}</p>
            </div>
          )}
        </div>
      )}
    </main>
  )
}
