import { useState } from "react"
import { createPortal } from "react-dom"
import {
  coCreationFee,
  coCreationLabel,
  coCreationPrice,
  formatPrice,
  type Product,
} from "./products"

// Prototype checkout: shows what the person is buying (the product they picked plus
// Co-Creation) and the concept sheet that goes with it. It takes no payment and sends nothing.
type Props = {
  lang: "en" | "it"
  product: Product
  onClose: () => void
  onDownloadSheet: () => void
}

const copy = {
  en: {
    back: "Back",
    title: "Checkout",
    badge: "Prototype",
    notice: "Prototype checkout. No payment is taken and nothing is sent.",
    contact: "Contact",
    email: "Email",
    delivery: "Delivery address",
    first: "First name",
    last: "Last name",
    address: "Address",
    city: "City",
    zip: "Postal code",
    country: "Country",
    method: "Delivery method",
    customization: "Personalization",
    customizationNote: "Online, in a 1:1 call with your Dream Maker. Your item ships within 10 days.",
    receive: "Where do you want to receive it?",
    online: "Ship to my address",
    onlineNote: "Delivered to the address you enter.",
    store: "Pick up in store",
    storeNote: "Collect it at the store you choose.",
    pickStore: "Choose a store",
    storeLabel: "Store",
    free: "Free",
    payment: "Payment",
    paymentNote: "Payment is not part of this prototype.",
    summary: "Order summary",
    listPrice: "Product",
    fee: "Co-Creation",
    shipping: "Delivery",
    total: "Total",
    sheet: "Your concept sheet is included.",
    works: "Chosen works",
    download: "Download concept sheet",
    place: "Place prototype order",
    doneTitle: "Prototype order placed",
    doneText:
      "Nothing was charged. In the real flow, your Dream Maker would now receive your concept sheet and get in touch to define the rest of the design.",
    doneBack: "Back to the concept sheet",
  },
  it: {
    back: "Indietro",
    title: "Checkout",
    badge: "Prototipo",
    notice: "Checkout di prototipo. Nessun pagamento viene effettuato e nulla viene inviato.",
    contact: "Contatto",
    email: "Email",
    delivery: "Indirizzo di consegna",
    first: "Nome",
    last: "Cognome",
    address: "Indirizzo",
    city: "Città",
    zip: "CAP",
    country: "Paese",
    method: "Metodo di consegna",
    customization: "Personalizzazione",
    customizationNote: "Online, in una videochiamata 1:1 con il tuo Dream Maker. L'articolo viene spedito entro 10 giorni.",
    receive: "Dove vuoi riceverlo?",
    online: "Spedizione al mio indirizzo",
    onlineNote: "Consegnato all'indirizzo che inserisci.",
    store: "Ritiro in negozio",
    storeNote: "Ritiralo nel negozio che scegli.",
    pickStore: "Scegli un negozio",
    storeLabel: "Negozio",
    free: "Gratis",
    payment: "Pagamento",
    paymentNote: "Il pagamento non fa parte di questo prototipo.",
    summary: "Riepilogo ordine",
    listPrice: "Prodotto",
    fee: "Co-Creation",
    shipping: "Consegna",
    total: "Totale",
    sheet: "Il tuo concept sheet è incluso.",
    works: "Opere scelte",
    download: "Scarica il concept sheet",
    place: "Conferma ordine di prototipo",
    doneTitle: "Ordine di prototipo confermato",
    doneText:
      "Non è stato addebitato nulla. Nel flusso reale, il tuo Dream Maker riceverebbe ora il concept sheet e ti contatterebbe per definire il resto del design.",
    doneBack: "Torna al concept sheet",
  },
}

// Placeholder list: replace with the real Dream Maker stores.
const stores = ["Milan", "Venice", "Seoul", "San Francisco", "Tokyo"]

export default function Checkout({ lang, product, onClose, onDownloadSheet }: Props) {
  const t = copy[lang]
  const [method, setMethod] = useState<"online" | "store">("online")
  const [placed, setPlaced] = useState(false)
  const total = coCreationPrice(product)

  return createPortal(
    <div className="ck" role="dialog" aria-modal="true" aria-label={t.title}>
      <header className="ck-bar">
        <button className="ck-back" type="button" onClick={onClose}>
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <path d="M20 12H4M10 6l-6 6 6 6" />
          </svg>
          {t.back}
        </button>
        <h1>{t.title}</h1>
        <span className="ck-badge">{t.badge}</span>
      </header>
      <p className="ck-notice" role="note">
        {t.notice}
      </p>

      {placed ? (
        <div className="ck-done" role="status">
          <h2>{t.doneTitle}</h2>
          <p>{t.doneText}</p>
          <button className="ck-download" type="button" onClick={onDownloadSheet}>
            {t.download}
          </button>
          <button className="ck-primary" type="button" onClick={onClose}>
            {t.doneBack}
          </button>
        </div>
      ) : (
        <form
          className="ck-grid"
          onSubmit={(event) => {
            event.preventDefault()
            setPlaced(true)
          }}
        >
          <aside className="ck-summary">
            <h2>{t.summary}</h2>
            <div className="ck-item">
              <img src={product.image} alt="" />
              <div>
                <strong>{product.name}</strong>
                <span>{coCreationLabel}</span>
              </div>
              <b>{formatPrice(total)}</b>
            </div>
            <dl className="ck-lines">
              <div>
                <dt>{t.listPrice}</dt>
                <dd>{formatPrice(product.price)}</dd>
              </div>
              <div>
                <dt>{t.fee}</dt>
                <dd>{formatPrice(coCreationFee)}</dd>
              </div>
              <div>
                <dt>{t.shipping}</dt>
                <dd>{t.free}</dd>
              </div>
              <div className="ck-total">
                <dt>{t.total}</dt>
                <dd>{formatPrice(total)}</dd>
              </div>
            </dl>
            <p className="ck-included">{t.sheet}</p>
            <button className="ck-download" type="button" onClick={onDownloadSheet}>
              {t.download}
            </button>
          </aside>

          <div className="ck-fields">
            <section>
              <h2>{t.contact}</h2>
              <label>
                {t.email}
                <input type="email" name="email" autoComplete="off" required />
              </label>
            </section>
            <section>
              <h2>{t.method}</h2>
              <p className="ck-pay">
                <strong>{t.customization}</strong>
                <br />
                {t.customizationNote}
              </p>
              <p className="ck-receive">{t.receive}</p>
              {(["online", "store"] as const).map((key) => (
                <label className={`ck-radio${method === key ? " is-on" : ""}`} key={key}>
                  <input
                    type="radio"
                    name="method"
                    checked={method === key}
                    onChange={() => setMethod(key)}
                  />
                  <span>
                    <strong>{key === "online" ? t.online : t.store}</strong>
                    <small>{key === "online" ? t.onlineNote : t.storeNote}</small>
                  </span>
                </label>
              ))}
              {method === "store" && (
                <label>
                  {t.storeLabel}
                  <select name="store" defaultValue="" required>
                    <option value="" disabled>
                      {t.pickStore}
                    </option>
                    {stores.map((store) => (
                      <option key={store} value={store}>
                        {store}
                      </option>
                    ))}
                  </select>
                </label>
              )}
            </section>
            {method === "online" && (
              <section>
                <h2>{t.delivery}</h2>
                <div className="ck-row">
                  <label>
                    {t.first}
                    <input name="first" autoComplete="off" required />
                  </label>
                  <label>
                    {t.last}
                    <input name="last" autoComplete="off" required />
                  </label>
                </div>
                <label>
                  {t.address}
                  <input name="address" autoComplete="off" required />
                </label>
                <div className="ck-row">
                  <label>
                    {t.city}
                    <input name="city" autoComplete="off" required />
                  </label>
                  <label>
                    {t.zip}
                    <input name="zip" autoComplete="off" required />
                  </label>
                </div>
                <label>
                  {t.country}
                  <select name="country" defaultValue={lang === "it" ? "IT" : "US"}>
                    <option value="IT">Italia</option>
                    <option value="US">United States</option>
                    <option value="GB">United Kingdom</option>
                    <option value="FR">France</option>
                  </select>
                </label>
              </section>
            )}
            <section>
              <h2>{t.payment}</h2>
              <p className="ck-pay">{t.paymentNote}</p>
            </section>
            <button className="ck-primary" type="submit">
              {t.place} · {formatPrice(total)}
            </button>
          </div>
        </form>
      )}
    </div>,
    document.body,
  )
}
