import { useEffect, useRef, useState } from "react"
import { createPortal } from "react-dom"
import {
  categoryLabels,
  categoryOrder,
  categoryThumbs,
  formatPrice,
  type Product,
  type ProductCategory,
} from "./products"

const TITLE =
  "Pick an item where you would like to showcase your story and explore an initial direction and possibilities."

export function ProductPopup({
  products,
  selectedId,
  onSelect,
  onClose,
}: {
  products: Product[]
  selectedId: string
  onSelect: (id: string) => void
  onClose: () => void
}) {
  const selected = products.find((product) => product.id === selectedId)
  const [category, setCategory] = useState<ProductCategory>(
    selected?.category ?? "Shoe",
  )
  const [closing, setClosing] = useState(false)
  const [previousFocus] = useState(() => document.activeElement as HTMLElement | null)
  const [thumb, setThumb] = useState({ width: 100, left: 0 })
  const panelRef = useRef<HTMLDivElement>(null)
  const gridRef = useRef<HTMLUListElement>(null)
  const closeRef = useRef<HTMLButtonElement>(null)
  const items = products.filter((product) => product.category === category)

  const requestClose = () => {
    if (closing) return
    setClosing(true)
    window.setTimeout(onClose, 220)
  }

  // Blur and lock everything behind the popup; give focus back when it closes.
  useEffect(() => {
    const root = document.getElementById("root")
    if (root) root.inert = true
    closeRef.current?.focus()
    return () => {
      if (root) root.inert = false
      window.setTimeout(() => previousFocus?.focus(), 0)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault()
        requestClose()
        return
      }
      if (event.key !== "Tab") return
      const focusable = Array.from(
        panelRef.current?.querySelectorAll<HTMLElement>("button:not([disabled])") ?? [],
      )
      if (focusable.length === 0) return
      const first = focusable[0]
      const last = focusable[focusable.length - 1]
      const active = document.activeElement
      if (event.shiftKey && (active === first || !panelRef.current?.contains(active))) {
        event.preventDefault()
        last.focus()
      } else if (!event.shiftKey && (active === last || !panelRef.current?.contains(active))) {
        event.preventDefault()
        first.focus()
      }
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [closing])

  // Scroll indicator: how much of the row is visible, and where.
  const updateThumb = () => {
    const grid = gridRef.current
    if (!grid || grid.scrollWidth === 0) return
    setThumb({
      width: Math.min(100, (grid.clientWidth / grid.scrollWidth) * 100),
      left: (grid.scrollLeft / grid.scrollWidth) * 100,
    })
  }
  useEffect(() => {
    const grid = gridRef.current
    if (!grid) return
    grid.scrollLeft = 0
    updateThumb()
    const observer = new ResizeObserver(updateThumb)
    observer.observe(grid)
    return () => observer.disconnect()
  }, [category])

  const choose = (id: string) => {
    onSelect(id)
    requestClose()
  }

  return createPortal(
    <div
      className={`product-popup${closing ? " product-popup-closing" : ""}`}
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) requestClose()
      }}
    >
      <div
        ref={panelRef}
        className="product-popup-panel"
        role="dialog"
        aria-modal="true"
        aria-labelledby="product-popup-title"
      >
        <button
          ref={closeRef}
          className="popup-close"
          type="button"
          onClick={requestClose}
          aria-label="Close"
        >
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <path d="M5 5l14 14M19 5L5 19" />
          </svg>
        </button>

        <p className="popup-title" id="product-popup-title">
          {TITLE}
        </p>

        <div className="popup-cats" role="group" aria-label="Product categories">
          {categoryOrder.map((key) => (
            <button
              key={key}
              type="button"
              className={`popup-cat${key === category ? " popup-cat-active" : ""}`}
              aria-pressed={key === category}
              onClick={() => setCategory(key)}
            >
              <img src={categoryThumbs[key]} alt="" draggable={false} />
              <span>{categoryLabels[key]}</span>
            </button>
          ))}
        </div>

        <ul
          className="popup-grid"
          ref={gridRef}
          key={category}
          onScroll={updateThumb}
        >
          {items.map((product) => (
            <li key={product.id}>
              <button
                type="button"
                className={`popup-item${product.id === selectedId ? " popup-item-selected" : ""}`}
                onClick={() => choose(product.id)}
                aria-current={product.id === selectedId ? "true" : undefined}
              >
                <span className="popup-photo">
                  <img src={product.image} alt="" draggable={false} />
                  {product.inStoreOnly && (
                    <span className="popup-tag">Personalizzabile solo in-store</span>
                  )}
                  {product.isNew && <span className="popup-new">NEW IN</span>}
                  {product.sparkle && (
                    <svg className="popup-sparkle" viewBox="0 0 24 24" aria-hidden="true">
                      <path d="M10 6.5l1.7 3.7 4 .5-3 2.7.8 4-3.5-2-3.5 2 .8-4-3-2.7 4-.5zM19 2v5M16.5 4.5h5" />
                    </svg>
                  )}
                </span>
                <span className="popup-name">{product.name}</span>
                <span className="popup-price">{formatPrice(product.price)}</span>
              </button>
            </li>
          ))}
        </ul>

        <div className="popup-progress" aria-hidden="true">
          <span style={{ width: `${thumb.width}%`, left: `${thumb.left}%` }} />
        </div>
      </div>
    </div>,
    document.body,
  )
}
