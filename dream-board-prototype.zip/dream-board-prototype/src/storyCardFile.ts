// Renders the Concept Sheet (Figma 948:831) to a PNG on a canvas: no dependencies.
// Layout is drawn at 2x the 700x927 template. The paper grain and the blue splatter
// are generated in code. Chosen works are shown as many tiles as the person pinned.

export type SheetImage = { image: string; label: string }

export type SheetData = {
  title: string
  summary: string
  styleTitle: string
  style: string
  images: SheetImage[]
  id: string
  logo: string
  disclaimer: string
}

const S = 2
const W = 700 * S
const H = 927 * S
const LEFT = 41 * S
const COL = 618.4 * S
const GREY = "#6c665d"
const FONT = '"DIN 2014", "DIN Alternate", Arial, sans-serif'

const loadImage = (src: string) =>
  new Promise<HTMLImageElement | null>((resolve) => {
    const img = new Image()
    img.crossOrigin = "anonymous"
    img.onload = () => resolve(img)
    img.onerror = () => resolve(null)
    img.src = src
  })

const wrap = (ctx: CanvasRenderingContext2D, text: string, maxWidth: number) => {
  const lines: string[] = []
  let line = ""
  for (const word of text.split(/\s+/).filter(Boolean)) {
    const test = line ? `${line} ${word}` : word
    if (ctx.measureText(test).width > maxWidth && line) {
      lines.push(line)
      line = word
    } else line = test
  }
  if (line) lines.push(line)
  return lines
}

const paragraph = (
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
) => {
  const lines = wrap(ctx, text, maxWidth)
  lines.forEach((line, i) => ctx.fillText(line, x, y + i * lineHeight))
  return y + lines.length * lineHeight
}

// Small seeded random so the paper looks the same every time.
const rng = (seed: number) => () => {
  seed = (seed * 16807) % 2147483647
  return (seed - 1) / 2147483646
}

const drawPaper = (ctx: CanvasRenderingContext2D) => {
  ctx.fillStyle = "#f4efe5"
  ctx.fillRect(0, 0, W, H)
  const rand = rng(48271)
  for (let i = 0; i < 26000; i++) {
    const x = rand() * W
    const y = rand() * H
    const dark = rand() > 0.5
    ctx.fillStyle = dark ? "rgba(120, 100, 70, 0.07)" : "rgba(255, 255, 255, 0.35)"
    ctx.fillRect(x, y, 2 + rand() * 2, 2 + rand() * 2)
  }
  // Blue splatter, top right.
  const blue = ["#4f8ccb", "#6aa1d8", "#3f7fc0", "#8bb6e0"]
  for (let i = 0; i < 26; i++) {
    const a = rand() * Math.PI * 2
    const d = Math.pow(rand(), 1.6) * 230
    const x = W - 20 + Math.cos(a) * d * 0.55 - 30
    const y = 40 + Math.abs(Math.sin(a)) * d * 0.6
    const r = 2 + rand() * 7 * (1 - d / 300)
    ctx.fillStyle = blue[Math.floor(rand() * blue.length)]
    ctx.globalAlpha = 0.55 + rand() * 0.4
    ctx.beginPath()
    ctx.arc(x, y, Math.max(r, 2), 0, Math.PI * 2)
    ctx.fill()
  }
  ctx.globalAlpha = 1
}

export async function renderConceptSheet(data: SheetData): Promise<Blob | null> {
  try {
    await Promise.all([
      document.fonts.load(`600 ${34 * S}px "DIN 2014"`),
      document.fonts.load(`400 ${16 * S}px "DIN 2014"`),
    ])
  } catch {
    /* fall back to Arial */
  }
  const canvas = document.createElement("canvas")
  canvas.width = W
  canvas.height = H
  const ctx = canvas.getContext("2d")
  if (!ctx) return null
  ctx.textBaseline = "alphabetic"

  drawPaper(ctx)

  // Title
  ctx.textAlign = "center"
  ctx.fillStyle = "#000"
  ctx.font = `600 ${33.7 * S}px ${FONT}`
  ctx.fillText(data.title.toUpperCase(), W / 2, 98 * S)

  // Story recap
  ctx.textAlign = "left"
  ctx.fillStyle = GREY
  ctx.font = `400 ${16 * S}px ${FONT}`
  paragraph(ctx, data.summary, LEFT, 168 * S, COL, 21 * S)

  // Visual style
  ctx.fillStyle = "#000"
  ctx.font = `600 ${20 * S}px ${FONT}`
  ctx.fillText(data.styleTitle.toUpperCase(), LEFT, 372 * S)
  ctx.fillStyle = GREY
  ctx.font = `400 ${16 * S}px ${FONT}`
  paragraph(ctx, data.style, LEFT, 404 * S, COL, 21 * S)

  // Chosen works: one tile per pinned image, left to right.
  const n = Math.max(data.images.length, 1)
  const gap = 18 * S
  const tile = Math.min(192.8 * S, (COL - gap * (n - 1)) / n)
  const top = 501 * S
  const images = await Promise.all(data.images.map((item) => loadImage(item.image)))
  data.images.forEach((item, i) => {
    const x = LEFT + i * (tile + gap)
    const r = 7.2 * S
    ctx.save()
    ctx.beginPath()
    ctx.roundRect(x, top, tile, tile, r)
    ctx.clip()
    const img = images[i]
    if (img) {
      const s = Math.max(tile / img.width, tile / img.height)
      const sw = tile / s
      const sh = tile / s
      ctx.drawImage(img, (img.width - sw) / 2, (img.height - sh) / 2, sw, sh, x, top, tile, tile)
    } else {
      ctx.fillStyle = "#e4dfd5"
      ctx.fillRect(x, top, tile, tile)
    }
    ctx.restore()
    ctx.fillStyle = "#000"
    ctx.font = `600 ${12 * S}px ${FONT}`
    paragraph(ctx, item.label, x, top + tile + 20 * S, tile, 15 * S)
  })

  // Footer: the Golden Goose logo as provided
  ctx.textAlign = "center"
  const logo = await loadImage(data.logo)
  if (logo) {
    const lw = 183 * S
    const lh = (lw * logo.height) / logo.width
    ctx.drawImage(logo, (W - lw) / 2, 814 * S - lh / 2, lw, lh)
  }
  ctx.fillStyle = "rgba(0, 0, 0, 0.6)"
  ctx.font = `600 ${16.8 * S}px ${FONT}`
  ctx.fillText(`ID ${data.id}`, W / 2, 864 * S)
  ctx.fillStyle = "#6a6a6a"
  ctx.font = `400 ${10 * S}px ${FONT}`
  ctx.fillText(data.disclaimer, W / 2, 888 * S)

  return new Promise((resolve) => canvas.toBlob(resolve, "image/png"))
}

export function downloadBlob(blob: Blob, name = "dream-maker-concept-sheet.png") {
  const url = URL.createObjectURL(blob)
  const link = document.createElement("a")
  link.href = url
  link.download = name
  document.body.appendChild(link)
  link.click()
  link.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 4000)
}

// Keep a text within a length, cutting at a word and closing with an ellipsis.
export const clip = (text: string, max: number) => {
  const t = text.replace(/\s+/g, " ").trim()
  if (t.length <= max) return t
  const cut = t.slice(0, max - 1)
  return `${cut.slice(0, cut.lastIndexOf(" ") > max * 0.6 ? cut.lastIndexOf(" ") : cut.length).replace(/[,;:.\s]+$/, "")}…`
}
