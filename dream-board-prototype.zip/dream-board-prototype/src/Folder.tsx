// @framerSupportedLayoutWidth auto
// @framerSupportedLayoutHeight auto

import * as React from "react"
import {
    useLayoutEffect,
    useMemo,
    useRef,
    useState,
    CSSProperties,
    useEffect,
    startTransition,
} from "react"
import { addPropertyControls, ControlType } from "framer"
import { motion, useReducedMotion } from "framer-motion"

type PaperOffset = { x: number; y: number }

interface FolderProps {
    color: string
    size: number
    cornerRadius: number

    hoverLift: boolean
    enableMagnet: boolean
    duration: number

    paper1Src?: string
    symbolSrc?: string
    paper2Src?: string
    paper3Src?: string

    width?: number
    height?: number

    canvasMoveMode?: boolean
    runtimeDrag?: boolean
}

const BASE_W = 100
const BASE_H = 80
const DEFAULT_PAPER_IMAGE =
    "https://framerusercontent.com/images/gVNfqILnTY3Vf95VrzTmkLyBpI.png?width=442&height=588&kb=10"
const DEFAULT_SYMBOL_IMAGE =
    "https://framerusercontent.com/images/gntu1SkEGSEUGFw8v21nwt74I.png?width=48&height=69&kb=1"

function Folder(props: FolderProps) {
    const {
        color,
        size,
        cornerRadius,
        duration,
        paper1Src,
        symbolSrc,
        width,
        height,
        canvasMoveMode = true,
        runtimeDrag = false,
    } = props

    const prefersReducedMotion = useReducedMotion()
    const resolvedPaper1Src = paper1Src || DEFAULT_PAPER_IMAGE
    const resolvedSymbolSrc = symbolSrc || DEFAULT_SYMBOL_IMAGE

    // Natural content size
    const contentW = BASE_W * size
    const contentH = BASE_H * size

    // 1) Measure the frame once it has a real size
    const rootRef = useRef<HTMLDivElement | null>(null)
    const [box, setBox] = useState({ w: contentW, h: contentH })
    const [measured, setMeasured] = useState(false)

    useLayoutEffect(() => {
        const el = rootRef.current
        if (!el) return

        const update = () => {
            const cw = el.clientWidth
            const ch = el.clientHeight
            if (cw > 0 && ch > 0) {
                setBox({ w: cw, h: ch })
                setMeasured(true)
            }
        }

        // Read once synchronously
        update()

        // Keep an observer in case Framer applies size after mount
        const ro = new ResizeObserver(() => {
            update()
        })
        ro.observe(el)

        return () => ro.disconnect()
    }, [contentW, contentH])

    // 2) Preload images, so the first open does not reflow when images appear
    const [imagesReady, setImagesReady] = useState(false)
    useEffect(() => {
        startTransition(() => setImagesReady(false))
        const srcs = [resolvedPaper1Src, resolvedSymbolSrc].filter(
            Boolean
        ) as string[]
        if (srcs.length === 0) {
            startTransition(() => setImagesReady(true))
            return
        }
        let settled = false
        let done = 0
        const timeoutId = window.setTimeout(() => {
            if (!settled) {
                settled = true
                startTransition(() => setImagesReady(true))
            }
        }, 2500)
        const imgs = srcs.map((s) => {
            const im = new Image()
            const finish = () => {
                if (settled) return
                done += 1
                if (done >= srcs.length) {
                    settled = true
                    startTransition(() => setImagesReady(true))
                }
            }
            im.onload = finish
            im.onerror = finish
            im.src = s
            if (im.complete) finish()
            return im
        })
        return () => {
            window.clearTimeout(timeoutId)
            // break references
            imgs.forEach((i) => {
                // @ts-ignore
                i.onload = i.onerror = null
            })
        }
    }, [resolvedPaper1Src, resolvedSymbolSrc])

    // 3) Arm transitions only after measurement and images are ready and one RAF has passed
    const [animReady, setAnimReady] = useState(false)
    useLayoutEffect(() => {
        if (!measured || !imagesReady) return
        let id = requestAnimationFrame(() => {
            // allow the browser to paint once before enabling transitions
            id = requestAnimationFrame(() => setAnimReady(true))
        })
        return () => cancelAnimationFrame(id)
    }, [measured, imagesReady])

    // Uniform fit scale
    const fitScale = useMemo(() => {
        const { w, h } = box
        if (!w || !h) return 1
        const s = Math.min(w / contentW, h / contentH)
        return s > 0 ? s : 1
    }, [box, contentW, contentH])

    const backColor = color
    const paperCol1 = "#E6E6E6"
    const initialPaperOffset: PaperOffset = { x: 0, y: 0 }

    const tr = (txPct: string, tyPct: string, off: PaperOffset, extra = "") =>
        `translate(calc(${txPct} + ${off.x.toFixed(1)}px), calc(${tyPct} + ${off.y.toFixed(1)}px))${
            extra ? " " + extra : ""
        }`

    const closedT = (o: PaperOffset) => tr("-50%", "-28%", o, "rotate(4.9deg)")
    // Root sizing
    const rootStyle: CSSProperties = canvasMoveMode
        ? {
              width: typeof width === "number" ? width : "100%",
              height: typeof height === "number" ? height : "100%",
              position: "relative",
              display: "grid",
              placeItems: "center",
              overflow: "visible",
          }
        : {
              width: typeof width === "number" ? width : "auto",
              height: typeof height === "number" ? height : "auto",
              position: "relative",
              overflow: "visible",
          }

    // Canvas wrapper we scale
    const canvasBase: CSSProperties = {
        width: contentW,
        height: contentH,
        willChange: "transform",
        pointerEvents: "auto",
        cursor: "default",
    }

    const baseTransform = `scale(${fitScale})`

    const canvasStyle: CSSProperties = canvasMoveMode
        ? {
              ...canvasBase,
              transform: baseTransform,
              transformOrigin: "center",
          }
        : {
              ...canvasBase,
              position: "absolute",
              left: "50%",
              top: "50%",
              transform: `translate(-50%, -50%) ${baseTransform}`,
              transformOrigin: "center",
          }

    // Back panel in natural size, outer canvas scales it
    const backStyle: CSSProperties = {
        position: "relative",
        width: BASE_W,
        height: BASE_H,
        background: backColor,
        borderRadius: `0px ${cornerRadius}px ${cornerRadius}px ${cornerRadius}px`,
        transform: `scale(${size})`,
        transformOrigin: "top left",
        boxShadow: "0 3px 10px rgba(0,0,0,0.18)",
        zIndex: 1,
    }

    const tabStyle: CSSProperties = {
        position: "absolute",
        zIndex: 1,
        bottom: "98%",
        left: 0,
        width: 30,
        height: 10,
        background: backColor,
        borderRadius: `${Math.max(0, cornerRadius / 2)}px ${Math.max(
            0,
            cornerRadius / 2
        )}px 0 0`,
        boxShadow: "0 2px 6px rgba(0,0,0,0.12)",
    }

    // Transition is disabled until animReady, which prevents the first click bounce
    const transition = animReady ? `transform ${duration}s ease-in-out` : "none"

    const paperShellBase: CSSProperties = {
        position: "absolute",
        zIndex: 2,
        bottom: "10%",
        left: "50%",
        transition,
        willChange: "transform",
    }

    const paperInnerStyle: CSSProperties = {
        width: "100%",
        height: "100%",
        borderRadius: 12,
        overflow: "hidden",
        display: "grid",
        placeItems: "center",
        background: "#fff",
    }

    const imgStyle: CSSProperties = {
        width: "100%",
        height: "100%",
        objectFit: "contain",
        pointerEvents: "none",
        display: "block",
    }
    const symbolStyle: CSSProperties = {
        position: "absolute",
        left: "50%",
        top: "50%",
        transform: "translate(-50%, -50%)",
        width: 14,
        height: 20,
        objectFit: "contain",
        pointerEvents: "none",
        display: "block",
    }

    const paper1ShellStyle = (o: PaperOffset): CSSProperties => ({
        ...paperShellBase,
        width: "70%",
        height: "80%",
        transform: closedT(o),
    })

    const paperFloatTransition = prefersReducedMotion
        ? { duration: 0 }
        : {
              duration: 2.8,
              repeat: Infinity,
              ease: "easeInOut" as const,
              times: [0, 0.36, 0.7, 1],
          }

    const revealPx = Math.round(BASE_H * 0.12)
    const frontCommon: CSSProperties = {
        position: "absolute",
        zIndex: 3,
        width: "100%",
        height: `calc(100% - ${revealPx}px)`,
        top: `${revealPx}px`,
        background: color,
        borderRadius: `${Math.max(5, cornerRadius - 5)}px ${cornerRadius}px ${cornerRadius}px ${cornerRadius}px`,
        transformOrigin: "bottom",
        transition,
        boxShadow: "inset 0 -1px 0 rgba(0,0,0,0.08)",
        pointerEvents: "none",
    }

    const frontLeft: CSSProperties = {
        ...frontCommon,
        transform: "none",
    }

    const frontRight: CSSProperties = {
        ...frontCommon,
        transform: "none",
    }

    return (
        <div ref={rootRef} style={rootStyle}>
            <motion.div
                style={canvasStyle}
                drag={!!runtimeDrag}
                dragMomentum={false}
                dragElastic={0}
            >
                <div style={backStyle}>
                    <div style={tabStyle} aria-hidden />
                    <div
                        style={paper1ShellStyle(initialPaperOffset)}
                    >
                        <motion.div
                            style={{ ...paperInnerStyle, background: paperCol1 }}
                            animate={
                                prefersReducedMotion
                                    ? { y: 0 }
                                    : { y: [0, -4, -2, 0] }
                            }
                            transition={paperFloatTransition}
                        >
                            <img
                                src={resolvedPaper1Src}
                                alt="Paper 1"
                                style={imgStyle}
                            />
                        </motion.div>
                    </div>

                    {/* front flaps */}
                    <div style={frontLeft} />
                    <div style={frontRight}>
                        <img
                            src={resolvedSymbolSrc}
                            alt=""
                            style={symbolStyle}
                            aria-hidden
                        />
                    </div>
                </div>
            </motion.div>
        </div>
    )
}

Folder.defaultProps = {
    width: undefined,
    height: undefined,

    color: "#FFE0B8",
    size: 2,
    cornerRadius: 10,

    hoverLift: true,
    enableMagnet: true,
    duration: 0.3,

    paper1Src: "",
    symbolSrc: "",
    paper2Src: "",
    paper3Src: "",

    canvasMoveMode: true,
    runtimeDrag: false,
} as Partial<FolderProps>

addPropertyControls(Folder, {
    color: { type: ControlType.Color, title: "Colour" },
    size: {
        type: ControlType.Number,
        title: "Size",
        min: 0.5,
        max: 6,
        step: 0.1,
    },
    cornerRadius: {
        type: ControlType.Number,
        title: "Radius",
        min: 0,
        max: 24,
        step: 1,
    },

    hoverLift: { type: ControlType.Boolean, title: "Hover" },
    enableMagnet: { type: ControlType.Boolean, title: "Magnet" },
    duration: {
        type: ControlType.Number,
        title: "Duration",
        min: 0.05,
        max: 1.2,
        step: 0.01,
    },

    paper1Src: { type: ControlType.Image, title: "Paper 1" },
    symbolSrc: { type: ControlType.Image, title: "Symbol" },
    paper2Src: { type: ControlType.Image, title: "Paper 2" },
    paper3Src: { type: ControlType.Image, title: "Paper 3" },

    canvasMoveMode: { type: ControlType.Boolean, title: "Canvas move mode" },
    runtimeDrag: { type: ControlType.Boolean, title: "Runtime drag" },
})

export default Folder
